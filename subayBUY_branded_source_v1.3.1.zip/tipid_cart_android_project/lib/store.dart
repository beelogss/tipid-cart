import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// All trips, saved on the phone. No login, no cloud.
class Store extends ChangeNotifier {
  static const String _key = 'tipid_cart_v1';
  static const String _wishlistKey = 'subaybuy_wishlist_v1';
  static const String _priceHistoryKey = 'subaybuy_price_history_v1';

  final List<Trip> trips = <Trip>[];
  final List<WishlistEntry> wishlist = <WishlistEntry>[];
  final List<PriceRecord> priceHistory = <PriceRecord>[];

  Trip? tripById(String id) {
    for (final Trip t in trips) {
      if (t.id == id) return t;
    }
    return null;
  }

  Future<void> load() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final String? raw = p.getString(_key);
      if (raw != null) {
        final List<dynamic> list = jsonDecode(raw) as List<dynamic>;
        trips
          ..clear()
          ..addAll(list.map((dynamic e) => Trip.fromJson(e as Map<String, dynamic>)));
      }
      final String? savedWishlist = p.getString(_wishlistKey);
      if (savedWishlist != null) {
        final List<dynamic> list = jsonDecode(savedWishlist) as List<dynamic>;
        wishlist
          ..clear()
          ..addAll(list.map((dynamic e) => WishlistEntry.fromJson(e as Map<String, dynamic>)));
      }
      final String? savedHistory = p.getString(_priceHistoryKey);
      if (savedHistory != null) {
        final List<dynamic> list = jsonDecode(savedHistory) as List<dynamic>;
        priceHistory
          ..clear()
          ..addAll(list.map((dynamic e) => PriceRecord.fromJson(e as Map<String, dynamic>)));
      }
      // Backfill price observations from existing trips once, so the feature
      // is useful immediately after updating an older installation.
      if (priceHistory.isEmpty && trips.isNotEmpty) {
        for (final Trip trip in trips) {
          for (final Item item in trip.items) {
            if (item.priceCents > 0) {
              priceHistory.add(PriceRecord(
                id: '${item.id}_${trip.id}',
                name: item.name,
                priceCents: item.priceCents,
                category: item.cat,
                recordedAt: trip.date,
              ));
            }
          }
        }
        priceHistory.sort((PriceRecord a, PriceRecord b) => b.recordedAt.compareTo(a.recordedAt));
        if (priceHistory.length > 500) {
          priceHistory.removeRange(500, priceHistory.length);
        }
      }
    } catch (_) {
      // Corrupt or missing data: start empty rather than crash.
    }
    notifyListeners();
  }

  Future<void> _save() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString(
        _key,
        jsonEncode(trips.map((Trip t) => t.toJson()).toList()),
      );
      await p.setString(_wishlistKey, jsonEncode(wishlist.map((WishlistEntry item) => item.toJson()).toList()));
      await p.setString(_priceHistoryKey, jsonEncode(priceHistory.map((PriceRecord item) => item.toJson()).toList()));
    } catch (_) {}
  }

  int _qty(int v) => v < 1 ? 1 : (v > 99 ? 99 : v);

  void _changed() {
    notifyListeners();
    _save();
  }

  Trip addTrip(String name, int budgetCents) {
    final Trip t = Trip(
      id: newId(),
      name: name,
      date: DateTime.now(),
      budgetCents: budgetCents,
    );
    trips.insert(0, t);
    _changed();
    return t;
  }

  void addSampleItems(Trip t) {
    final List<Item> samples = <Item>[
      Item(id: newId(), name: 'Hazelnut spread 350g', priceCents: 7975, cat: 'Grocery'),
      Item(id: '${newId()}b', name: 'Fresh milk 1L', priceCents: 11250, qty: 2, cat: 'Drinks'),
      Item(id: '${newId()}c', name: 'Dishwashing liquid 500ml', priceCents: 6400, cat: 'Household'),
    ];
    t.items.addAll(samples);
    for (final Item item in samples) {
      _recordPrice(item);
    }
    _changed();
  }

  void updateTrip(Trip t, {String? name, int? budgetCents, bool? done}) {
    if (name != null) t.name = name;
    if (budgetCents != null) t.budgetCents = budgetCents;
    if (done != null) t.done = done;
    _changed();
  }

  void deleteTrip(Trip t) {
    trips.removeWhere((Trip x) => x.id == t.id);
    _changed();
  }

  void addItem(Trip t, Item item) {
    t.items.insert(0, item);
    _recordPrice(item);
    _changed();
  }

  void insertItemAt(Trip t, int index, Item item) {
    final int at = index < 0 ? 0 : (index > t.items.length ? t.items.length : index);
    t.items.insert(at, item);
    _changed();
  }

  void removeItem(Trip t, String itemId) {
    t.items.removeWhere((Item i) => i.id == itemId);
    _changed();
  }

  void changeQty(Trip t, Item item, int delta) {
    item.qty = _qty(item.qty + delta);
    _changed();
  }

  void editItem(Item item, {required String name, required int priceCents, required int qty, required String cat}) {
    final bool priceChanged = item.priceCents != priceCents || item.name.trim().toLowerCase() != name.trim().toLowerCase();
    item.name = name;
    item.priceCents = priceCents;
    item.qty = _qty(qty);
    item.cat = cat;
    if (priceChanged) _recordPrice(item);
    _changed();
  }

  void _recordPrice(Item item) {
    if (item.name.trim().isEmpty || item.priceCents <= 0) return;
    priceHistory.insert(0, PriceRecord(
      id: newId(),
      name: item.name.trim(),
      priceCents: item.priceCents,
      category: item.cat,
      recordedAt: DateTime.now(),
    ));
    if (priceHistory.length > 500) priceHistory.removeRange(500, priceHistory.length);
  }

  void addWishlistEntry(WishlistEntry entry) {
    wishlist.insert(0, entry);
    _changed();
  }

  void updateWishlistEntry(WishlistEntry entry, {required String name, required int estimatedPriceCents, required String category}) {
    entry
      ..name = name.trim()
      ..estimatedPriceCents = estimatedPriceCents
      ..category = category;
    _changed();
  }

  void removeWishlistEntry(String id) {
    wishlist.removeWhere((WishlistEntry entry) => entry.id == id);
    _changed();
  }
}
