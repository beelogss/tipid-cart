import 'dart:async';

import 'package:flutter/material.dart';

/// Displays a short-lived in-app notice with an optional Undo button.
///
/// This deliberately uses an OverlayEntry and Dart Timer instead of SnackBar.
/// SnackBar timeout behavior can vary with accessibility settings and route
/// transitions. The timer here is explicit and always dismisses the notice.
class TransientNoticeController {
  OverlayEntry? _entry;
  Timer? _timer;
  bool _disposed = false;

  void show(
    BuildContext context,
    String message, {
    VoidCallback? onUndo,
    Duration duration = const Duration(seconds: 2),
  }) {
    if (_disposed) return;

    dismiss();

    final OverlayState overlay = Overlay.of(context, rootOverlay: true);
    late final OverlayEntry entry;

    entry = OverlayEntry(
      builder: (BuildContext overlayContext) {
        final double bottomInset =
            MediaQuery.viewPaddingOf(overlayContext).bottom;

        return Positioned(
          left: 16,
          right: 16,
          bottom: bottomInset + 16,
          child: Material(
            color: const Color(0xFF332B2A),
            elevation: 10,
            borderRadius: BorderRadius.circular(12),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 10, 12),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Semantics(
                      liveRegion: true,
                      child: Text(
                        message,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                  if (onUndo != null) ...<Widget>[
                    const SizedBox(width: 8),
                    TextButton(
                      style: TextButton.styleFrom(
                        foregroundColor: const Color(0xFFFFBDB2),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 8,
                        ),
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      onPressed: () {
                        dismiss();
                        onUndo();
                      },
                      child: const Text('Undo'),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );

    _entry = entry;
    overlay.insert(entry);
    _timer = Timer(duration, dismiss);
  }

  /// Removes the current notice immediately and cancels its timer.
  void dismiss() {
    _timer?.cancel();
    _timer = null;

    final OverlayEntry? entry = _entry;
    _entry = null;
    if (entry == null) return;

    // Remove even if the entry has not completed its first frame yet.
    entry.remove();
    entry.dispose();
  }

  /// Call when the owning screen is disposed so notices never outlive it.
  void dispose() {
    if (_disposed) return;
    _disposed = true;
    dismiss();
  }
}
