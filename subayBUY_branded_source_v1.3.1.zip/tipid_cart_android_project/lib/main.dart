import 'package:flutter/material.dart';

import 'models.dart';
import 'store.dart';
import 'trip_screen.dart';
import 'sheets.dart';
import 'extra_screens.dart';

const Color kCoral = Color(0xFFFF525F);
const Color kNavy = Color(0xFF252839);
const Color kPeach = Color(0xFFFFBDB2);
const Color kSoftPeach = Color(0xFFFFF2F0);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final Store store = Store();
  await store.load();
  runApp(TipidCartApp(store: store));
}

class TipidCartApp extends StatelessWidget {
  const TipidCartApp({super.key, required this.store});
  final Store store;

  ThemeData _theme() {
    final ColorScheme scheme = ColorScheme.fromSeed(
      seedColor: kCoral,
      brightness: Brightness.light,
    ).copyWith(
      primary: kCoral,
      onPrimary: Colors.white,
      secondary: kNavy,
      onSecondary: Colors.white,
      tertiary: kPeach,
      surface: Colors.white,
      onSurface: kNavy,
      error: const Color(0xFFB3261E),
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: Colors.white,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: kNavy,
        surfaceTintColor: Colors.transparent,
        scrolledUnderElevation: 0,
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        margin: EdgeInsets.zero,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: kSoftPeach,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFFFE0DC)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: kCoral, width: 1.6),
        ),
      ),
      dividerColor: const Color(0xFFFFE0DC),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'subayBUY',
      debugShowCheckedModeBanner: false,
      theme: _theme(),
      themeMode: ThemeMode.light,
      home: HomeScreen(store: store),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.store});
  final Store store;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _query = '';
  String _filter = 'All';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _newTrip(BuildContext context) async {
    final TripSheetResult? r = await showTripSheet(context);
    if (r == null || r.delete || !context.mounted) return;
    final Trip t = widget.store.addTrip(r.name, r.budgetCents);
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (BuildContext c) => TripScreen(store: widget.store, tripId: t.id),
    ));
  }

  void _open(BuildContext context, Trip t) {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (BuildContext c) => TripScreen(store: widget.store, tripId: t.id),
    ));
  }

  bool _matches(Trip trip) {
    if (_filter == 'Active' && trip.done) return false;
    if (_filter == 'Completed' && !trip.done) return false;
    final String q = _query.trim().toLowerCase();
    if (q.isEmpty) return true;
    if (trip.name.toLowerCase().contains(q)) return true;
    return trip.items.any((Item item) => item.name.toLowerCase().contains(q));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListenableBuilder(
          listenable: widget.store,
          builder: (BuildContext context, Widget? _) {
            final List<Trip> all = widget.store.trips;
            final List<Trip> active = all.where((Trip t) => !t.done && _matches(t)).toList();
            final List<Trip> completed = all.where((Trip t) => t.done && _matches(t)).toList();
            final DateTime now = DateTime.now();
            final List<Trip> monthTrips = all.where((Trip t) => t.date.year == now.year && t.date.month == now.month).toList();
            final int monthSpent = monthTrips.fold<int>(0, (int sum, Trip t) => sum + t.spentCents);
            final bool hasResults = active.isNotEmpty || completed.isNotEmpty;
            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
              children: <Widget>[
                Center(
                  child: SizedBox(
                    width: 238,
                    height: 146,
                    child: Image.asset(
                      'assets/subaybuy_logo.png',
                      fit: BoxFit.contain,
                      alignment: Alignment.center,
                      semanticLabel: 'subayBUY logo',
                    ),
                  ),
                ),
                const SizedBox(height: 0),
                const Text(
                  'Track what you buy. Control what you spend.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: kNavy, fontSize: 13, fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 12),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => WishlistScreen(store: widget.store))),
                        icon: const Icon(Icons.favorite_border_rounded, size: 18),
                        label: const Text('Wishlist'),
                        style: OutlinedButton.styleFrom(foregroundColor: kNavy, side: const BorderSide(color: Color(0xFFFFD5D0))),
                      ),
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => InsightsScreen(store: widget.store))),
                        icon: const Icon(Icons.insights_rounded, size: 18),
                        label: const Text('Insights'),
                        style: OutlinedButton.styleFrom(foregroundColor: kNavy, side: const BorderSide(color: Color(0xFFFFD5D0))),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _OverviewCard(trips: all.where((Trip t) => !t.done).toList()),
                const SizedBox(height: 12),
                _MonthlyInsightCard(monthSpent: monthSpent, tripCount: monthTrips.length),
                const SizedBox(height: 18),
                SizedBox(
                  height: 54,
                  child: FilledButton.icon(
                    onPressed: () => _newTrip(context),
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('New shopping trip', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    style: FilledButton.styleFrom(
                      backgroundColor: kCoral,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    ),
                  ),
                ),
                const SizedBox(height: 22),
                TextField(
                  controller: _searchController,
                  onChanged: (String value) => setState(() => _query = value),
                  textInputAction: TextInputAction.search,
                  decoration: InputDecoration(
                    hintText: 'Search trips or items',
                    prefixIcon: const Icon(Icons.search_rounded, color: kNavy),
                    suffixIcon: _query.isEmpty
                        ? null
                        : IconButton(
                            tooltip: 'Clear search',
                            onPressed: () {
                              _searchController.clear();
                              setState(() => _query = '');
                            },
                            icon: const Icon(Icons.close_rounded),
                          ),
                  ),
                ),
                const SizedBox(height: 10),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: <String>['All', 'Active', 'Completed'].map((String option) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(option),
                          selected: _filter == option,
                          onSelected: (_) => setState(() => _filter = option),
                          selectedColor: kCoral,
                          labelStyle: TextStyle(color: _filter == option ? Colors.white : kNavy, fontWeight: FontWeight.w700),
                        ),
                      );
                    }).toList(),
                  ),
                ),
                if (active.isNotEmpty) ...<Widget>[
                  _SectionLabel('ACTIVE TRIPS', count: active.length),
                  ...active.map((Trip t) => _TripRow(trip: t, onTap: () => _open(context, t))),
                ],
                if (completed.isNotEmpty) ...<Widget>[
                  _SectionLabel('PAST TRIPS', count: completed.length),
                  ...completed.map((Trip t) => _TripRow(trip: t, onTap: () => _open(context, t))),
                ],
                if (all.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 22),
                    child: _EmptyTrips(
                      onSample: () {
                        final Trip t = widget.store.addTrip('Sample trip (examples)', 200000);
                        widget.store.addSampleItems(t);
                        _open(context, t);
                      },
                    ),
                  )
                else if (!hasResults)
                  Padding(
                    padding: const EdgeInsets.only(top: 24),
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: kSoftPeach,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: const Color(0xFFFFD5D0)),
                      ),
                      child: const Column(
                        children: <Widget>[
                          Icon(Icons.search_off_rounded, size: 34, color: kCoral),
                          SizedBox(height: 8),
                          Text('No matching trips', style: TextStyle(color: kNavy, fontWeight: FontWeight.w800, fontSize: 16)),
                          SizedBox(height: 4),
                          Text('Try another keyword or switch the trip filter.', textAlign: TextAlign.center, style: TextStyle(color: kNavy)),
                        ],
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _EmptyTrips extends StatelessWidget {
  const _EmptyTrips({required this.onSample});
  final VoidCallback onSample;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: kSoftPeach,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFFFD5D0)),
      ),
      child: Column(
        children: <Widget>[
          const Icon(Icons.shopping_basket_outlined, size: 38, color: kCoral),
          const SizedBox(height: 8),
          const Text('Your shopping space starts here', textAlign: TextAlign.center, style: TextStyle(color: kNavy, fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 5),
          const Text(
            'Create a trip, set your budget, then scan a shelf price tag or add products manually. Your data stays on this phone.',
            textAlign: TextAlign.center,
            style: TextStyle(color: kNavy),
          ),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: onSample,
            icon: const Icon(Icons.lightbulb_outline_rounded),
            label: const Text('Try a sample trip'),
            style: OutlinedButton.styleFrom(foregroundColor: kNavy, side: const BorderSide(color: kCoral)),
          ),
        ],
      ),
    );
  }
}

class _OverviewCard extends StatelessWidget {
  const _OverviewCard({required this.trips});
  final List<Trip> trips;

  @override
  Widget build(BuildContext context) {
    final int budget = trips.fold<int>(0, (int sum, Trip t) => sum + t.budgetCents);
    final int spent = trips.fold<int>(0, (int sum, Trip t) => sum + t.spentCents);
    final int remaining = budget - spent;
    return Container(
      padding: const EdgeInsets.all(19),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: <Color>[kNavy, kCoral], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(22),
        boxShadow: <BoxShadow>[BoxShadow(color: kCoral.withValues(alpha: 0.16), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Text('ACTIVE SHOPPING BUDGET', style: TextStyle(color: kPeach, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.3)),
          const SizedBox(height: 7),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(peso(remaining), style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: -0.8)),
          ),
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Expanded(child: _OverviewMetric(label: 'Spent', value: peso(spent))),
              Expanded(child: _OverviewMetric(label: 'Budget', value: peso(budget))),
              Expanded(child: _OverviewMetric(label: 'Active trips', value: '${trips.length}')),
            ],
          ),
          if (trips.isEmpty) ...<Widget>[
            const SizedBox(height: 12),
            const Text('Start a shopping trip to see your remaining budget.', style: TextStyle(color: kPeach, fontSize: 12)),
          ],
        ],
      ),
    );
  }
}

class _MonthlyInsightCard extends StatelessWidget {
  const _MonthlyInsightCard({required this.monthSpent, required this.tripCount});
  final int monthSpent;
  final int tripCount;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: kSoftPeach,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFFFD5D0)),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: kPeach.withValues(alpha: 0.45), borderRadius: BorderRadius.circular(13)),
            child: const Icon(Icons.calendar_month_rounded, color: kNavy),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text('SPENT THIS MONTH', style: TextStyle(color: kNavy, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
                const SizedBox(height: 3),
                Text(peso(monthSpent), style: const TextStyle(color: kNavy, fontSize: 20, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          Text('$tripCount trip${tripCount == 1 ? '' : 's'}', style: const TextStyle(color: kNavy, fontWeight: FontWeight.w700, fontSize: 12)),
        ],
      ),
    );
  }
}

class _OverviewMetric extends StatelessWidget {
  const _OverviewMetric({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, style: const TextStyle(color: kPeach, fontSize: 11)),
          const SizedBox(height: 3),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800)),
        ],
      );
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text, {required this.count});
  final String text;
  final int count;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 22, 2, 9),
      child: Row(
        children: <Widget>[
          Text(text, style: const TextStyle(color: kNavy, fontSize: 12, letterSpacing: 1.2, fontWeight: FontWeight.w900)),
          const SizedBox(width: 7),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            decoration: BoxDecoration(color: kPeach.withValues(alpha: 0.45), borderRadius: BorderRadius.circular(20)),
            child: Text('$count', style: const TextStyle(color: kNavy, fontSize: 10, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

class _TripRow extends StatelessWidget {
  const _TripRow({required this.trip, required this.onTap});
  final Trip trip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final int left = trip.leftCents;
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: Color(0xFFFFD5D0))),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          child: Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(color: kSoftPeach, borderRadius: BorderRadius.circular(13)),
                child: Icon(trip.done ? Icons.check_circle_outline_rounded : Icons.shopping_cart_outlined, color: kCoral),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(trip.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: kNavy, fontWeight: FontWeight.w800, fontSize: 15)),
                    const SizedBox(height: 3),
                    Text('${showDate(trip.date)} · ${trip.itemCount} item${trip.itemCount == 1 ? '' : 's'}', style: const TextStyle(color: Color(0xFF777989), fontSize: 12)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(peso(left), style: TextStyle(color: left < 0 ? kCoral : kNavy, fontSize: 17, fontWeight: FontWeight.w900)),
                  Text('left of ${peso(trip.budgetCents)}', style: const TextStyle(color: Color(0xFF777989), fontSize: 10)),
                ],
              ),
              const SizedBox(width: 3),
              const Icon(Icons.chevron_right_rounded, color: Color(0xFF9B9DAB)),
            ],
          ),
        ),
      ),
    );
  }
}
