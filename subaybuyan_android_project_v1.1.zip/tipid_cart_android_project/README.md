# subayBUYan

**Track what you buy. Control what you spend.**

An offline-first shopping budget tracker. Create a shopping trip, set a budget, scan shelf price tags with on-device Google ML Kit text recognition, and track what remains. No login or cloud account is required.

## Current features

- Shopping trips with individual budgets
- Cart items with quantity, category, and optional captured price-tag photo
- Manual item entry and editing
- On-device photo OCR using Google ML Kit
- Local trip storage using SharedPreferences
- Budget totals and remaining-balance calculations

## Build the Android APK from a phone using GitHub Actions

1. Upload this project ZIP to the GitHub repository root as `subaybuyan_android_project.zip`.
2. Add the workflow file from `.github/workflows/subaybuyan-apk.yml` to the repository at the same path.
3. Open the repository's **Actions** tab and wait for **Build subayBUYan APK** to finish.
4. Open the successful run and download the `subaybuyan-apk` artifact.
5. Extract the downloaded artifact ZIP and install `app-debug.apk`.

The new app uses a new Android application ID so it can be installed alongside the original Tipid Cart while you test it. Existing Tipid Cart local data is not automatically copied into the new app.

## Scanner notes

The current scanner takes a photo and reads text locally with Google ML Kit. It is not a live continuous scanner and it does not guarantee product-name recognition. Always verify a detected price before relying on it for a purchase.
