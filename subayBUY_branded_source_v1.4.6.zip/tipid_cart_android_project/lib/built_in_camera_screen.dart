import 'dart:async';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'camera_preview_geometry.dart';

const Color _cameraCoral = Color(0xFFFF525F);

class BuiltInCameraScreen extends StatefulWidget {
  const BuiltInCameraScreen({super.key});

  @override
  State<BuiltInCameraScreen> createState() => _BuiltInCameraScreenState();
}

class _BuiltInCameraScreenState extends State<BuiltInCameraScreen>
    with WidgetsBindingObserver {
  CameraController? _controller;
  bool _loading = true;
  bool _opening = false;
  bool _capturing = false;
  bool _torchOn = false;
  bool _showGuide = true;
  double _minZoom = 1.0;
  double _maxZoom = 1.0;
  double _zoom = 1.0;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_openCamera());
  }

  Future<void> _openCamera() async {
    if (_opening || !mounted) return;
    _opening = true;
    if (mounted && !_loading) {
      setState(() { _loading = true; _error = null; });
    } else {
      _error = null;
    }
    CameraController? nextController;
    try {
      final List<CameraDescription> cameras = await availableCameras();
      if (cameras.isEmpty) throw CameraException('NoCamera', 'No camera was found on this device.');
      final CameraDescription selected = cameras.firstWhere(
        (CameraDescription camera) => camera.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );
      nextController = CameraController(
        selected,
        ResolutionPreset.high,
        enableAudio: false,
      );
      await nextController.initialize();
      await nextController.setFlashMode(FlashMode.off);
      double minZoom = 1.0;
      double maxZoom = 1.0;
      try {
        minZoom = await nextController.getMinZoomLevel();
        maxZoom = await nextController.getMaxZoomLevel();
      } on CameraException {
        // Some camera devices do not expose zoom controls. The preview still works.
      }
      if (!minZoom.isFinite || minZoom <= 0) minZoom = 1.0;
      if (!maxZoom.isFinite || maxZoom < minZoom) maxZoom = minZoom;
      if (!mounted) {
        await nextController.dispose();
        return;
      }
      _controller = nextController;
      setState(() {
        _loading = false;
        _torchOn = false;
        _minZoom = minZoom;
        _maxZoom = maxZoom >= minZoom ? maxZoom : minZoom;
        _zoom = minZoom;
      });
    } on CameraException catch (error) {
      if (nextController != null) await nextController.dispose();
      if (mounted) {
        setState(() {
          _loading = false;
          _error = error.description ?? error.code;
        });
      }
    } catch (error) {
      if (nextController != null) await nextController.dispose();
      if (mounted) setState(() { _loading = false; _error = error.toString(); });
    } finally {
      _opening = false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) {
      final CameraController? old = _controller;
      _controller = null;
      if (old != null) unawaited(old.dispose());
    } else if (state == AppLifecycleState.resumed && _controller == null) {
      unawaited(_openCamera());
    }
  }

  Future<void> _toggleTorch() async {
    final CameraController? controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    final bool next = !_torchOn;
    try {
      await controller.setFlashMode(next ? FlashMode.torch : FlashMode.off);
      if (mounted) setState(() => _torchOn = next);
    } on CameraException {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Flash is not available on this camera.')),
        );
      }
    }
  }

  Future<void> _applyZoom(double zoom) async {
    final CameraController? controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    try {
      await controller.setZoomLevel(zoom);
    } on CameraException {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Zoom is not available on this camera.'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  Widget _buildCoverPreview(CameraController controller) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        // Match camera's own CameraPreview orientation handling.
        final DeviceOrientation orientation = controller.value.deviceOrientation;
        final bool landscape = orientation == DeviceOrientation.landscapeLeft ||
            orientation == DeviceOrientation.landscapeRight;
        final double previewAspectRatio = landscape
            ? controller.value.aspectRatio
            : 1 / controller.value.aspectRatio;
        final double viewportAspectRatio = constraints.maxWidth / constraints.maxHeight;
        final double scale = cameraPreviewCoverScale(
          viewportAspectRatio: viewportAspectRatio,
          previewAspectRatio: previewAspectRatio,
        );
        return ClipRect(
          child: Transform.scale(
            scale: scale,
            child: Center(
              child: AspectRatio(
                aspectRatio: previewAspectRatio,
                child: CameraPreview(controller),
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _capture() async {
    final CameraController? controller = _controller;
    if (controller == null || !controller.value.isInitialized || _capturing) return;
    setState(() => _capturing = true);
    try {
      unawaited(HapticFeedback.lightImpact());
      final XFile image = await controller.takePicture();
      if (!mounted) return;
      Navigator.of(context).pop<String>(image.path);
    } on CameraException catch (error) {
      if (mounted) {
        setState(() => _capturing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.description ?? 'Unable to capture photo.')),
        );
      }
    } catch (_) {
      if (mounted) {
        setState(() => _capturing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Unable to capture photo. Please try again.')),
        );
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    final CameraController? old = _controller;
    _controller = null;
    if (old != null) unawaited(old.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final CameraController? controller = _controller;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('Scan price tag'),
        actions: <Widget>[
          IconButton(
            tooltip: _torchOn ? 'Turn flash off' : 'Turn flash on',
            onPressed: controller == null ? null : _toggleTorch,
            icon: Icon(_torchOn ? Icons.flash_on_rounded : Icons.flash_off_rounded),
          ),
          IconButton(
            tooltip: _showGuide ? 'Hide framing guide' : 'Show framing guide',
            onPressed: () => setState(() => _showGuide = !_showGuide),
            icon: Icon(_showGuide ? Icons.center_focus_strong : Icons.center_focus_weak),
          ),
        ],
      ),
      body: _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    const Icon(Icons.no_photography_outlined, color: Colors.white70, size: 48),
                    const SizedBox(height: 14),
                    const Text('Camera unavailable', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                    const SizedBox(height: 18),
                    FilledButton(onPressed: () => unawaited(_openCamera()), child: const Text('Try again')),
                  ],
                ),
              ),
            )
          : _loading || controller == null || !controller.value.isInitialized
              ? const Center(child: CircularProgressIndicator(color: _cameraCoral))
              : Column(
                  children: <Widget>[
                    Expanded(
                      child: Stack(
                        fit: StackFit.expand,
                        children: <Widget>[
                          _buildCoverPreview(controller),
                          if (_showGuide)
                            IgnorePointer(
                              child: Center(
                                child: Container(
                                  width: MediaQuery.sizeOf(context).width * 0.84,
                                  height: 172,
                                  decoration: BoxDecoration(
                                    border: Border.all(color: _cameraCoral, width: 2.5),
                                    borderRadius: BorderRadius.circular(18),
                                  ),
                                ),
                              ),
                            ),
                          if (_showGuide)
                            const Positioned(
                              left: 20,
                              right: 20,
                              bottom: 22,
                              child: Text(
                                'I-frame ang buong price tag sa loob ng guide.',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, shadows: <Shadow>[Shadow(blurRadius: 8, color: Colors.black)]),
                              ),
                            ),
                        ],
                      ),
                    ),
                    SafeArea(
                      top: false,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 10, 20, 16),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            if (_maxZoom > _minZoom)
                              Row(
                                children: <Widget>[
                                  const Icon(Icons.zoom_out_rounded, color: Colors.white70, size: 20),
                                  Expanded(
                                    child: Slider(
                                      value: _zoom.clamp(_minZoom, _maxZoom).toDouble(),
                                      min: _minZoom,
                                      max: _maxZoom,
                                      onChanged: _capturing
                                          ? null
                                          : (double value) => setState(() => _zoom = value),
                                      onChangeEnd: _capturing ? null : (double value) => unawaited(_applyZoom(value)),
                                      activeColor: _cameraCoral,
                                      inactiveColor: Colors.white24,
                                    ),
                                  ),
                                  Text('${_zoom.toStringAsFixed(1)}×', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                                ],
                              ),
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: OutlinedButton(
                                    onPressed: _capturing ? null : () => Navigator.of(context).pop<String>(),
                                    style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54), minimumSize: const Size.fromHeight(52)),
                                    child: const Text('Cancel'),
                                  ),
                                ),
                                const SizedBox(width: 18),
                                SizedBox(
                                  width: 68,
                                  height: 68,
                                  child: FloatingActionButton(
                                    heroTag: 'capture-price-tag',
                                    onPressed: _capturing ? null : _capture,
                                    backgroundColor: _cameraCoral,
                                    foregroundColor: Colors.white,
                                    child: _capturing
                                        ? const CircularProgressIndicator(color: Colors.white)
                                        : const Icon(Icons.camera_alt_rounded, size: 30),
                                  ),
                                ),
                                const SizedBox(width: 18),
                                const Expanded(
                                  child: Text('Take photo', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }
}
