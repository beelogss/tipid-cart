import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tipid_cart/notifications.dart';

void main() {
  testWidgets(
    'notice auto-dismisses even with accessible navigation enabled',
    (WidgetTester tester) async {
      final TransientNoticeController controller =
          TransientNoticeController();
      final GlobalKey<ScaffoldState> scaffoldKey =
          GlobalKey<ScaffoldState>();

      await tester.pumpWidget(
        MaterialApp(
          builder: (BuildContext context, Widget? child) => MediaQuery(
            data: MediaQuery.of(context).copyWith(
              accessibleNavigation: true,
            ),
            child: child!,
          ),
          home: Scaffold(
            key: scaffoldKey,
            body: Builder(
              builder: (BuildContext context) => ElevatedButton(
                onPressed: () => controller.show(
                  context,
                  'Added Milk · ₱25.00',
                  onUndo: () {},
                ),
                child: const Text('Show notice'),
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.text('Show notice'));
      await tester.pump();

      expect(find.text('Added Milk · ₱25.00'), findsOneWidget);
      expect(find.text('Undo'), findsOneWidget);

      // The controller timer starts synchronously when show() is called.
      // It is independent of SnackBar/accessibility timeout behavior.
      await tester.pump(const Duration(seconds: 3));
      await tester.pump();

      expect(find.text('Added Milk · ₱25.00'), findsNothing);
      expect(find.text('Undo'), findsNothing);
      controller.dispose();
    },
  );

  testWidgets(
    'inline Undo works while the custom notice is visible',
    (WidgetTester tester) async {
      final TransientNoticeController controller =
          TransientNoticeController();
      int undoCount = 0;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Builder(
              builder: (BuildContext context) => TextButton(
                onPressed: () => controller.show(
                  context,
                  'Added Bread · ₱30.00',
                  onUndo: () => undoCount++,
                ),
                child: const Text('Show notice'),
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.text('Show notice'));
      await tester.pump();

      expect(find.text('Added Bread · ₱30.00'), findsOneWidget);
      expect(find.text('Undo'), findsOneWidget);

      await tester.tap(find.text('Undo'));
      await tester.pump();

      expect(undoCount, 1);
      expect(find.text('Added Bread · ₱30.00'), findsNothing);
      controller.dispose();
    },
  );

  testWidgets(
    'disposing the controller removes its active notice',
    (WidgetTester tester) async {
      final TransientNoticeController controller =
          TransientNoticeController();

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Builder(
              builder: (BuildContext context) => ElevatedButton(
                onPressed: () => controller.show(context, 'Temporary notice'),
                child: const Text('Show notice'),
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.text('Show notice'));
      await tester.pump();
      expect(find.text('Temporary notice'), findsOneWidget);

      controller.dispose();
      await tester.pump();

      expect(find.text('Temporary notice'), findsNothing);
    },
  );

  testWidgets(
    'a newer notice replaces the previous notice',
    (WidgetTester tester) async {
      final TransientNoticeController controller =
          TransientNoticeController();

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Builder(
              builder: (BuildContext context) => Column(
                children: <Widget>[
                  TextButton(
                    onPressed: () => controller.show(context, 'First notice'),
                    child: const Text('Show first'),
                  ),
                  TextButton(
                    onPressed: () => controller.show(context, 'Second notice'),
                    child: const Text('Show second'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.text('Show first'));
      await tester.pump();
      expect(find.text('First notice'), findsOneWidget);

      await tester.tap(find.text('Show second'));
      await tester.pump();
      expect(find.text('First notice'), findsNothing);
      expect(find.text('Second notice'), findsOneWidget);

      await tester.pump(const Duration(seconds: 3));
      await tester.pump();
      expect(find.text('Second notice'), findsNothing);
      controller.dispose();
    },
  );
}
