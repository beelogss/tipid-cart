import 'package:flutter_test/flutter_test.dart';
import 'package:tipid_cart/camera_preview_geometry.dart';

void main() {
  test('matching viewport and preview ratios need no scaling', () {
    expect(
      cameraPreviewCoverScale(
        viewportAspectRatio: 9 / 16,
        previewAspectRatio: 9 / 16,
      ),
      1.0,
    );
  });

  test('wider preview is cropped to cover a portrait viewport', () {
    final double scale = cameraPreviewCoverScale(
      viewportAspectRatio: 9 / 16,
      previewAspectRatio: 3 / 4,
    );
    expect(scale, closeTo((3 / 4) / (9 / 16), 0.0001));
    expect(scale, greaterThan(1));
  });

  test('invalid aspect ratios safely fall back to unity', () {
    expect(
      cameraPreviewCoverScale(
        viewportAspectRatio: 0,
        previewAspectRatio: 3 / 4,
      ),
      1.0,
    );
  });
}
