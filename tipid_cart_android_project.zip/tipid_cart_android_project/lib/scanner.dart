import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// One line of text found in the photo and how tall it is on the picture.
/// The tallest price on a shelf tag is almost always the selling price.
class OcrLine {
  const OcrLine(this.text, this.height);
  final String text;
  final double height;
}

class ScanResult {
  const ScanResult({this.name, this.priceCents, required this.category});
  final String? name;
  final int? priceCents;
  final String category;
}

final RegExp _dotPrice = RegExp(r'(\d{1,3}(?:,\d{3})+|\d{1,5})\.(\d{2})(?!\d)');
final RegExp _pesoWhole = RegExp(r'(?:₱|\bPHP|\bPhp|\bP)\s*(\d{1,5})(?![\d.,])');
final RegExp _perUnit = RegExp(
  r'/|\bper\b|\b\d+\s?(ml|g|kg|l|oz|pcs|pc)\b',
  caseSensitive: false,
);
final RegExp _size = RegExp(r'\b\d+(\.\d+)?\s?(ml|g|kg|l|oz|pcs|pc)\b', caseSensitive: false);
final RegExp _stopWords = RegExp(
  r'^(imported|sale|promo|promotion|price|regular|new|php|per|each|pc|pcs|save|only|now|was)$',
  caseSensitive: false,
);

int? _priceFrom(String text, {required bool allowWhole}) {
  final Match? m = _dotPrice.firstMatch(text);
  if (m != null) {
    final int whole = int.parse(m.group(1)!.replaceAll(',', ''));
    final int frac = int.parse(m.group(2)!);
    final int cents = whole * 100 + frac;
    if (cents > 0 && cents < 10000000) return cents;
  }
  if (allowWhole) {
    final Match? w = _pesoWhole.firstMatch(text);
    if (w != null) {
      final int cents = int.parse(w.group(1)!) * 100;
      if (cents > 0 && cents < 10000000) return cents;
    }
  }
  return null;
}

String _tidy(String s) {
  String t = s.replaceAll(RegExp(r'\s+'), ' ').trim();
  final bool allUpper = t == t.toUpperCase();
  if (allUpper) {
    t = t
        .split(' ')
        .map((String w) => w.isEmpty ? w : w[0] + w.substring(1).toLowerCase())
        .join(' ');
  }
  return t;
}

String _guessCategory(String all) {
  final String t = all.toLowerCase();
  bool has(List<String> words) => words.any(t.contains);
  if (has(<String>['milk', 'juice', 'coke', 'sprite', 'royal', 'pepsi', 'water', 'coffee', 'tea', 'soda', 'beer', 'drink'])) {
    return 'Drinks';
  }
  if (has(<String>['chips', 'biscuit', 'cookie', 'chocolate', 'candy', 'cracker', 'snack', 'wafer', 'nuts', 'popcorn'])) {
    return 'Snacks';
  }
  if (has(<String>['soap', 'shampoo', 'conditioner', 'toothpaste', 'lotion', 'deodorant', 'napkin', 'cologne', 'tooth'])) {
    return 'Personal care';
  }
  if (has(<String>['detergent', 'tissue', 'dishwashing', 'bleach', 'fabric', 'trash bag', 'cleaner', 'sponge', 'foil'])) {
    return 'Household';
  }
  return 'Grocery';
}

/// Pure function so it can be checked without a camera.
ScanResult parseLines(List<OcrLine> lines) {
  // 1. Price: the tallest line that looks like a price and is not a per-unit price.
  int? price;
  double bestH = -1;
  for (final OcrLine l in lines) {
    if (_perUnit.hasMatch(l.text)) continue;
    final int? c = _priceFrom(l.text, allowWhole: false);
    if (c != null && l.height > bestH) {
      price = c;
      bestH = l.height;
    }
  }
  if (price == null) {
    for (final OcrLine l in lines) {
      if (_perUnit.hasMatch(l.text)) continue;
      final int? c = _priceFrom(l.text, allowWhole: true);
      if (c != null && l.height > bestH) {
        price = c;
        bestH = l.height;
      }
    }
  }

  // 2. Name: the tallest line that is mostly letters and is not a price.
  String? name;
  double nameH = -1;
  for (final OcrLine l in lines) {
    final String t = l.text.trim();
    if (t.length < 3 || t.length > 45) continue;
    if (_stopWords.hasMatch(t)) continue;
    if (_dotPrice.hasMatch(t)) continue;
    final int letters = RegExp(r'[A-Za-z]').allMatches(t).length;
    final int digits = RegExp(r'\d').allMatches(t).length;
    if (letters < 3 || digits > letters) continue;
    if (l.height > nameH) {
      name = _tidy(t);
      nameH = l.height;
    }
  }
  if (name != null) {
    for (final OcrLine l in lines) {
      final Match? s = _size.firstMatch(l.text);
      if (s != null && !name!.toLowerCase().contains(s.group(0)!.toLowerCase())) {
        name = '$name ${s.group(0)!.trim()}';
        break;
      }
    }
  }

  final String all = lines.map((OcrLine l) => l.text).join(' ');
  return ScanResult(name: name, priceCents: price, category: _guessCategory(all));
}

/// Reads a photo on the phone with Google ML Kit. Works offline.
class PriceScanner {
  final TextRecognizer _recognizer = TextRecognizer(script: TextRecognitionScript.latin);

  Future<ScanResult> scan(String imagePath) async {
    final RecognizedText text = await _recognizer.processImage(InputImage.fromFilePath(imagePath));
    final List<OcrLine> lines = <OcrLine>[];
    for (final TextBlock b in text.blocks) {
      for (final TextLine l in b.lines) {
        lines.add(OcrLine(l.text, l.boundingBox.height));
      }
    }
    return parseLines(lines);
  }

  void dispose() {
    _recognizer.close();
  }
}
