import 'package:flutter/material.dart';

import 'models.dart';
import 'store.dart';
import 'trip_screen.dart';
import 'sheets.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final Store store = Store();
  await store.load();
  runApp(TipidCartApp(store: store));
}

class TipidCartApp extends StatelessWidget {
  const TipidCartApp({super.key, required this.store});
  final Store store;

  ThemeData _theme(Brightness b) {
    const Color coral = Color(0xFFFF525F);
    const Color navy = Color(0xFF252839);
    const Color peach = Color(0xFFFFBDB2);
    final bool dark = b == Brightness.dark;
    final ColorScheme scheme = ColorScheme.fromSeed(
      seedColor: coral,
      brightness: b,
      primary: coral,
      onPrimary: Colors.white,
      secondary: navy,
      onSecondary: Colors.white,
      tertiary: peach,
      surface: dark ? navy : Colors.white,
      onSurface: dark ? Colors.white : navy,
      error: const Color(0xFFB3261E),
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: dark ? navy : Colors.white,
      appBarTheme: AppBarTheme(
        backgroundColor: dark ? navy : Colors.white,
        foregroundColor: dark ? Colors.white : navy,
        surfaceTintColor: Colors.transparent,
        scrolledUnderElevation: 0,
      ),
      cardTheme: CardThemeData(
        color: dark ? const Color(0xFF34384A) : Colors.white,
        surfaceTintColor: Colors.transparent,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: dark ? const Color(0xFF34384A) : Colors.white,
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: coral, width: 2),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'subayBUY',
      debugShowCheckedModeBanner: false,
      theme: _theme(Brightness.light),
      darkTheme: _theme(Brightness.dark),
      themeMode: ThemeMode.system,
      home: HomeScreen(store: store),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.store});
  final Store store;

  Future<void> _newTrip(BuildContext context) async {
    final TripSheetResult? r = await showTripSheet(context);
    if (r == null || r.delete || !context.mounted) return;
    final Trip t = store.addTrip(r.name, r.budgetCents);
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => TripScreen(store: store, tripId: t.id)));
  }

  void _open(BuildContext context, Trip t) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => TripScreen(store: store, tripId: t.id)));
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: ListenableBuilder(
          listenable: store,
          builder: (BuildContext context, Widget? _) {
            final List<Trip> live = store.trips.where((Trip t) => !t.done).toList();
            final List<Trip> done = store.trips.where((Trip t) => t.done).toList();
            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
              children: <Widget>[
                Align(
                  alignment: Alignment.centerLeft,
                  child: Image.asset(
                    'assets/subaybuy_logo.png',
                    height: 82,
                    fit: BoxFit.contain,
                    alignment: Alignment.centerLeft,
                    semanticLabel: 'subayBUY',
                  ),
                ),
                const SizedBox(height: 4),
                Text('Track what you buy. Control what you spend.', style: TextStyle(color: theme.colorScheme.onSurfaceVariant)),
                const SizedBox(height: 16),
                _OverviewCard(trips: live, theme: theme),
                const SizedBox(height: 18),
                SizedBox(
                  height: 52,
                  child: FilledButton.icon(
                    onPressed: () => _newTrip(context),
                    icon: const Icon(Icons.add),
                    label: const Text('New trip', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  ),
                ),
                if (live.isNotEmpty) ...<Widget>[
                  _SectionLabel('ACTIVE'),
                  ...live.map((Trip t) => _TripRow(trip: t, onTap: () => _open(context, t))),
                ],
                if (done.isNotEmpty) ...<Widget>[
                  _SectionLabel('PAST TRIPS'),
                  ...done.map((Trip t) => _TripRow(trip: t, onTap: () => _open(context, t))),
                ],
                if (store.trips.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 22),
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: theme.colorScheme.outlineVariant, width: 1.5),
                      ),
                      child: Column(
                        children: <Widget>[
                          Text('No trips yet', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          Text(
                            'Start a trip, enter your budget, then point the camera at a shelf price tag. The price goes into your cart and comes off what is left.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: theme.colorScheme.onSurfaceVariant),
                          ),
                          const SizedBox(height: 14),
                          OutlinedButton(
                            onPressed: () {
                              final Trip t = store.addTrip('Sample trip (examples)', 200000);
                              store.addSampleItems(t);
                              _open(context, t);
                            },
                            child: const Text('Try a sample trip'),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _OverviewCard extends StatelessWidget {
  const _OverviewCard({required this.trips, required this.theme});
  final List<Trip> trips;
  final ThemeData theme;

  @override
  Widget build(BuildContext context) {
    final int budget = trips.fold<int>(0, (int sum, Trip t) => sum + t.budgetCents);
    final int spent = trips.fold<int>(0, (int sum, Trip t) => sum + t.spentCents);
    final int remaining = budget - spent;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: <Color>[Color(0xFF252839), Color(0xFFFF525F)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Text('ACTIVE SHOPPING BUDGET', style: TextStyle(color: Color(0xFFFFBDB2), fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.3)),
          const SizedBox(height: 7),
          Text(peso(remaining), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: -0.8)),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(child: _OverviewMetric(label: 'Spent', value: peso(spent))),
              Expanded(child: _OverviewMetric(label: 'Budget', value: peso(budget))),
              Expanded(child: _OverviewMetric(label: 'Active trips', value: '${trips.length}')),
            ],
          ),
          if (trips.isEmpty) ...<Widget>[
            const SizedBox(height: 10),
            const Text('Start a shopping trip to see your budget overview.', style: TextStyle(color: Color(0xFFFFBDB2), fontSize: 12)),
          ],
        ],
      ),
    );
  }
}

class _OverviewMetric extends StatelessWidget {
  const _OverviewMetric({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, style: const TextStyle(color: Color(0xFFFFBDB2), fontSize: 11)),
          const SizedBox(height: 3),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800)),
        ],
      );
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 24, 2, 8),
      child: Text(text, style: theme.textTheme.labelLarge?.copyWith(letterSpacing: 1.2, color: theme.colorScheme.onSurfaceVariant, fontWeight: FontWeight.w800)),
    );
  }
}

class _TripRow extends StatelessWidget {
  const _TripRow({required this.trip, required this.onTap});
  final Trip trip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme cs = theme.colorScheme;
    final int left = trip.leftCents;
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      color: cs.surfaceContainer,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: cs.outlineVariant)),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(trip.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 2),
                    Text(
                      '${showDate(trip.date)} · ${trip.itemCount} item${trip.itemCount == 1 ? '' : 's'}',
                      style: theme.textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(peso(left), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: left < 0 ? cs.error : null)),
                  Text('of ${peso(trip.budgetCents)}', style: theme.textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
