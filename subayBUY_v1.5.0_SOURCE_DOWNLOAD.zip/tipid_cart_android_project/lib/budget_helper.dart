import 'models.dart';

/// A safe, optional suggestion to reduce one unit from a multi-quantity item.
///
/// The app never applies these suggestions automatically. The user chooses
/// whether or not to reduce a quantity.
class BudgetSavingSuggestion {
  const BudgetSavingSuggestion({
    required this.item,
    required this.savingsCents,
  });

  final Item item;
  final int savingsCents;
}

/// Returns possible one-unit reductions, ordered from greatest saving to least.
List<BudgetSavingSuggestion> budgetSavingSuggestions(Trip trip) {
  final List<BudgetSavingSuggestion> suggestions = trip.items
      .where((Item item) => item.qty > 1 && item.priceCents > 0)
      .map(
        (Item item) => BudgetSavingSuggestion(
          item: item,
          savingsCents: item.priceCents,
        ),
      )
      .toList()
    ..sort(
      (BudgetSavingSuggestion a, BudgetSavingSuggestion b) =>
          b.savingsCents.compareTo(a.savingsCents),
    );

  return suggestions;
}
