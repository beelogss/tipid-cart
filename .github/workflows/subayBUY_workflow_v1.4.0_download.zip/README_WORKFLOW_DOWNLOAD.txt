subayBUY v1.4.0 GitHub workflow

This ZIP contains:
- subayBUY-build-v1.4.0.yml : upload this exact file to .github/workflows/ in your existing GitHub repository.
- subayBUY-build-v1.4.0.txt : identical plain-text backup if your phone cannot preview the YAML file.

IMPORTANT:
1. Do not upload this ZIP itself into .github/workflows.
2. Extract this ZIP on your phone first.
3. Upload the .yml file from the extracted folder to:
   https://github.com/beelogss/tipid-cart/tree/main/.github/workflows
4. Keep the filename exactly: subayBUY-build-v1.4.0.yml
5. Do not delete old ZIPs or workflow files.

This is only the workflow download fallback. It does not prove that the Flutter project compiles. GitHub Actions must run the tests and APK build.
