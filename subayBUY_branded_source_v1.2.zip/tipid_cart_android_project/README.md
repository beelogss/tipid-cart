# subayBUY

An offline-first Android shopping budget tracker. Create shopping trips, set budgets, scan shelf price tags with on-device OCR, add or edit items manually, and review trip spending. Data is stored locally on the device; no account is required.

## Included features

- Shopping trips with individual budgets and active/completed status
- Remaining-budget and monthly-spending overview
- Camera scanning and photo-gallery scanning for shelf price tags
- Editable OCR results, manual item entry, quantities, and product categories
- Search and category filters for trips and cart items
- Copyable trip summaries
- Local persistence using SharedPreferences
- subayBUY logo, coral/navy/peach/white theme, and custom Android launcher icon

## Brand colors

- White: `#FFFFFF`
- Coral: `#FF525F`
- Navy: `#252839`
- Peach: `#FFBDB2`

## Build from GitHub Actions

The repository-level workflow `/.github/workflows/subayBUY-build-v1.2.yml` extracts `subayBUY_branded_source.zip`, generates the Android project, generates launcher icons, runs tests and analysis, then builds an arm64 debug APK named `subayBUY.apk`.

The app keeps data locally under the existing `tipid_cart_v1` storage key. Keep the Flutter package name and Android application ID unchanged when making future updates.
