import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// All trips, saved on the phone. No login, no cloud.
class Store extends ChangeNotifier {
  static const String _key = 'tipid_cart_v1';

  final List<Trip> trips = <Trip>[];

  Trip? tripById(String id) {
    for (final Trip t in trips) {
      if (t.id == id) return t;
    }
    return null;
  }

  Future<void> load() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final String? raw = p.getString(_key);
      if (raw != null) {
        final List<dynamic> list = jsonDecode(raw) as List<dynamic>;
        trips
          ..clear()
          ..addAll(list.map((dynamic e) => Trip.fromJson(e as Map<String, dynamic>)));
      }
    } catch (_) {
      // Corrupt or missing data: start empty rather than crash.
    }
    notifyListeners();
  }

  Future<void> _save() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString(
        _key,
        jsonEncode(trips.map((Trip t) => t.toJson()).toList()),
      );
    } catch (_) {}
  }

  int _qty(int v) => v < 1 ? 1 : (v > 99 ? 99 : v);

  void _changed() {
    notifyListeners();
    _save();
  }

  Trip addTrip(String name, int budgetCents) {
    final Trip t = Trip(
      id: newId(),
      name: name,
      date: DateTime.now(),
      budgetCents: budgetCents,
    );
    trips.insert(0, t);
    _changed();
    return t;
  }

  void addSampleItems(Trip t) {
    t.items.addAll(<Item>[
      Item(id: newId(), name: 'Hazelnut spread 350g', priceCents: 7975, cat: 'Grocery'),
      Item(id: '${newId()}b', name: 'Fresh milk 1L', priceCents: 11250, qty: 2, cat: 'Drinks'),
      Item(id: '${newId()}c', name: 'Dishwashing liquid 500ml', priceCents: 6400, cat: 'Household'),
    ]);
    _changed();
  }

  void updateTrip(Trip t, {String? name, int? budgetCents, bool? done}) {
    if (name != null) t.name = name;
    if (budgetCents != null) t.budgetCents = budgetCents;
    if (done != null) t.done = done;
    _changed();
  }

  void deleteTrip(Trip t) {
    trips.removeWhere((Trip x) => x.id == t.id);
    _changed();
  }

  void addItem(Trip t, Item item) {
    t.items.insert(0, item);
    _changed();
  }

  void insertItemAt(Trip t, int index, Item item) {
    final int at = index < 0 ? 0 : (index > t.items.length ? t.items.length : index);
    t.items.insert(at, item);
    _changed();
  }

  void removeItem(Trip t, String itemId) {
    t.items.removeWhere((Item i) => i.id == itemId);
    _changed();
  }

  void changeQty(Trip t, Item item, int delta) {
    item.qty = _qty(item.qty + delta);
    _changed();
  }

  void editItem(Item item, {required String name, required int priceCents, required int qty, required String cat}) {
    item.name = name;
    item.priceCents = priceCents;
    item.qty = _qty(qty);
    item.cat = cat;
    _changed();
  }
}
