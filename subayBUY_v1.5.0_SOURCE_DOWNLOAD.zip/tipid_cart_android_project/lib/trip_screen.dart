import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import 'built_in_camera_screen.dart';

import 'budget_helper.dart';
import 'models.dart';
import 'notifications.dart';
import 'scanner.dart';
import 'sheets.dart';
import 'store.dart';

const Color kTag = Color(0xFF252839);
const Color kOnTag = Color(0xFFFFFFFF);
const Color kTagTrack = Color(0x55FFBDB2);
const Color kOver = Color(0xFFFF525F);
const Color kWarn = Color(0xFFFFBDB2);

class TripScreen extends StatefulWidget {
  const TripScreen({super.key, required this.store, required this.tripId});
  final Store store;
  final String tripId;

  @override
  State<TripScreen> createState() => _TripScreenState();
}

class _TripScreenState extends State<TripScreen> {
  final TransientNoticeController _noticeController = TransientNoticeController();
  final PriceScanner _scanner = PriceScanner();
  final ImagePicker _picker = ImagePicker();
  bool _busy = false;
  final TextEditingController _itemSearchController = TextEditingController();
  String _itemQuery = '';
  String _categoryFilter = 'All';

  @override
  void dispose() {
    _noticeController.dispose();
    _scanner.dispose();
    _itemSearchController.dispose();
    super.dispose();
  }

  Future<String> _keepImage(String tempPath) async {
    final Directory docs = await getApplicationDocumentsDirectory();
    final Directory dir = Directory('${docs.path}/scans');
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    final String dest = '${dir.path}/${newId()}.jpg';
    await File(tempPath).copy(dest);
    return dest;
  }

  void _snack(String msg, {VoidCallback? onUndo}) {
    if (!mounted) {
      return;
    }
    _noticeController.show(context, msg, onUndo: onUndo);
  }

  String _budgetChangeNote(Trip trip, int previousLeftCents) {
    final int currentLeftCents = trip.leftCents;
    if (previousLeftCents >= 0 && currentLeftCents < 0) {
      return ' · over budget by ${peso(-currentLeftCents)}';
    }
    if (previousLeftCents > 0 && currentLeftCents == 0) {
      return ' · budget fully used';
    }
    if (trip.budgetCents > 0) {
      final int beforeSpent = trip.budgetCents - previousLeftCents;
      final int afterSpent = trip.spentCents;
      final bool crossedEightyPercent =
          beforeSpent < trip.budgetCents * 0.8 &&
          afterSpent >= trip.budgetCents * 0.8;
      if (crossedEightyPercent) {
        return ' · 80% of your budget used';
      }
    }
    if (currentLeftCents < 0) {
      return ' · over budget by ${peso(-currentLeftCents)}';
    }
    return '';
  }

  List<PriceRecord> _recentProducts(Trip trip) {
    final Set<String> seen = <String>{};
    final List<PriceRecord> result = <PriceRecord>[];
    final Set<String> inCart = trip.items
        .map((Item item) => item.name.trim().toLowerCase())
        .toSet();

    for (final PriceRecord record in widget.store.priceHistory) {
      final String key = record.name.trim().toLowerCase();
      if (key.isEmpty || record.priceCents <= 0 || inCart.contains(key)) {
        continue;
      }
      if (seen.add(key)) {
        result.add(record);
        if (result.length == 5) {
          break;
        }
      }
    }
    return result;
  }

  void _quickAdd(Trip trip, PriceRecord record) {
    if (trip.done) {
      return;
    }
    final int previousLeft = trip.leftCents;
    final Item item = Item(
      id: newId(),
      name: record.name,
      priceCents: record.priceCents,
      cat: record.category,
    );
    widget.store.addItem(trip, item);
    HapticFeedback.mediumImpact();
    final String note = _budgetChangeNote(trip, previousLeft);
    _snack(
      'Added ${item.name} at its last saved price · ${peso(item.priceCents)}$note',
      onUndo: () => widget.store.removeItem(trip, item.id),
    );
  }

  void _changeQuantity(Trip trip, Item item, int delta) {
    if (trip.done) {
      return;
    }
    final int previousQty = item.qty;
    final int previousLeft = trip.leftCents;
    widget.store.changeQty(trip, item, delta);
    final int appliedDelta = item.qty - previousQty;
    if (appliedDelta == 0) {
      return;
    }

    HapticFeedback.selectionClick();
    final String note = _budgetChangeNote(trip, previousLeft);
    _snack(
      '${item.name} quantity: ${item.qty}$note',
      onUndo: () => widget.store.changeQty(trip, item, -appliedDelta),
    );
  }

  Future<void> _scan(Trip trip, {bool fromGallery = false}) async {
    if (_busy) {
      return;
    }
    // A previous notice belongs to this route. Remove it before opening the
    // camera/gallery so it cannot float over the scanner screen.
    _noticeController.dismiss();
    setState(() => _busy = true);
    try {
      String? imagePath;
      if (fromGallery) {
        final XFile? image = await _picker.pickImage(
          source: ImageSource.gallery,
          maxWidth: 1600,
          imageQuality: 88,
        );
        imagePath = image?.path;
      } else {
        imagePath = await Navigator.of(context).push<String>(
          MaterialPageRoute<String>(
            builder: (_) => const BuiltInCameraScreen(),
          ),
        );
      }
      if (imagePath == null || !mounted) {
        return;
      }

      final String path = await _keepImage(imagePath);
      final ScanResult result = await _scanner.scan(path);
      if (!mounted) {
        return;
      }
      if (result.priceCents != null) {
        final Item item = Item(
          id: newId(),
          name: result.name ?? 'Item',
          priceCents: result.priceCents!,
          cat: result.category,
          imagePath: path,
        );
        final int previousLeft = trip.leftCents;
        widget.store.addItem(trip, item);
        HapticFeedback.mediumImpact();
        final String note = _budgetChangeNote(trip, previousLeft);
        _snack(
          'Added ${item.name} · ${peso(item.priceCents)}$note',
          onUndo: () => widget.store.removeItem(trip, item.id),
        );
      } else {
        await _openItemSheet(
          trip,
          Item(id: newId(), name: result.name ?? '', priceCents: 0, cat: result.category, imagePath: path),
          isNew: true,
          note: 'Could not read the price. Type it in to add this item.',
        );
      }
    } catch (_) {
      if (mounted) {
        _snack('Could not read that image. Try again with the price tag filling the frame.');
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _openItemSheet(Trip trip, Item item, {required bool isNew, String? note}) async {
    final ItemSheetResult? r = await showItemSheet(context, item: item, isNew: isNew, note: note);
    if (r == null || !mounted) {
      return;
    }
    if (r.delete) {
      final int at = trip.items.indexOf(item);
      widget.store.removeItem(trip, item.id);
      HapticFeedback.selectionClick();
      _snack(
        'Removed ${item.name}',
        onUndo: () => widget.store.insertItemAt(trip, at < 0 ? 0 : at, item),
      );
      return;
    }

    final int previousLeft = trip.leftCents;
    if (isNew) {
      item
        ..name = r.name
        ..priceCents = r.priceCents
        ..qty = r.qty
        ..cat = r.cat;
      widget.store.addItem(trip, item);
      HapticFeedback.mediumImpact();
      final String note = _budgetChangeNote(trip, previousLeft);
      _snack(
        'Added ${item.name} · ${peso(item.priceCents)}$note',
        onUndo: () => widget.store.removeItem(trip, item.id),
      );
    } else {
      widget.store.editItem(
        item,
        name: r.name,
        priceCents: r.priceCents,
        qty: r.qty,
        cat: r.cat,
      );
      HapticFeedback.selectionClick();
      final String note = _budgetChangeNote(trip, previousLeft);
      _snack('Updated ${item.name}$note');
    }
  }

  Future<void> _editBudget(Trip trip) async {
    final TripSheetResult? r = await showTripSheet(context, name: trip.name, budgetCents: trip.budgetCents);
    if (r == null || !mounted) {
      return;
    }
    if (r.delete) {
      widget.store.deleteTrip(trip);
      Navigator.of(context).pop();
      return;
    }
    widget.store.updateTrip(trip, name: r.name, budgetCents: r.budgetCents);
  }

  Future<void> _finish(Trip trip) async {
    final bool over = trip.leftCents < 0;
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: const Text('Finish trip?'),
        content: Text(
          'Budget ${peso(trip.budgetCents)}\nSpent ${peso(trip.spentCents)}\n${over ? 'Over by' : 'Left over'} ${peso(trip.leftCents.abs())}',
        ),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Keep shopping')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Finish')),
        ],
      ),
    );
    if (ok == true) {
      widget.store.updateTrip(trip, done: true);
      HapticFeedback.heavyImpact();
      _snack('Shopping trip completed. Nice work!');
    }
  }

  Future<void> _copySummary(Trip trip) async {
    final List<String> lines = <String>[
      'subayBUY - ${trip.name}',
      showDate(trip.date),
      'Status: ${trip.done ? 'Completed' : 'Active'}',
      'Budget: ${peso(trip.budgetCents)}',
      'Spent: ${peso(trip.spentCents)}',
      'Remaining: ${peso(trip.leftCents)}',
      '',
      'ITEMS',
      ...trip.items.map((Item item) => '${item.name} | ${item.qty} x ${peso(item.priceCents)} = ${peso(item.lineCents)}'),
    ];
    await Clipboard.setData(ClipboardData(text: lines.join('\n')));
    if (mounted) {
      _snack('Trip summary copied. You can paste it into a message or note.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.store,
      builder: (BuildContext context, Widget? _) {
        final Trip? trip = widget.store.tripById(widget.tripId);
        if (trip == null) {
          return const Scaffold(body: Center(child: Text('Trip not found')));
        }
        final ThemeData theme = Theme.of(context);
        final List<String> categories = <String>{...trip.items.map((Item i) => i.cat)}.toList()..sort();
        categories.insert(0, 'All');
        final String selectedCategory = categories.contains(_categoryFilter) ? _categoryFilter : 'All';
        final String query = _itemQuery.trim().toLowerCase();
        final List<Item> visibleItems = trip.items.where((Item item) {
          final bool matchesText = query.isEmpty || item.name.toLowerCase().contains(query);
          final bool matchesCategory = selectedCategory == 'All' || item.cat == selectedCategory;
          return matchesText && matchesCategory;
        }).toList();
        final List<PriceRecord> recentProducts =
            trip.done ? <PriceRecord>[] : _recentProducts(trip);
        final List<BudgetSavingSuggestion> savingSuggestions =
            !trip.done && trip.leftCents < 0
                ? budgetSavingSuggestions(trip)
                : <BudgetSavingSuggestion>[];
        return Scaffold(
          appBar: AppBar(
            title: Text(trip.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            actions: <Widget>[
              IconButton(
                tooltip: 'Copy trip summary',
                onPressed: () => _copySummary(trip),
                icon: const Icon(Icons.copy_all_outlined),
              ),
              if (!trip.done)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilledButton.tonal(onPressed: () => _finish(trip), child: const Text('Finish')),
                )
              else
                Padding(
                  padding: const EdgeInsets.only(right: 16),
                  child: Center(child: Text('FINISHED', style: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w800))),
                ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            children: <Widget>[
              Text(showDate(trip.date), style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
              const SizedBox(height: 10),
              _TagCard(trip: trip, onTap: () => _editBudget(trip)),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 260),
                child: trip.done
                    ? Container(
                        key: const ValueKey<String>('trip-complete'),
                        margin: const EdgeInsets.only(top: 12),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFFEAF6EF),
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(color: const Color(0xFFB9DEC8)),
                        ),
                        child: const Row(
                          children: <Widget>[
                            Icon(Icons.check_circle_rounded, color: Color(0xFF26845B)),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Trip completed. Your summary is ready to copy.',
                                style: TextStyle(fontWeight: FontWeight.w700),
                              ),
                            ),
                          ],
                        ),
                      )
                    : const SizedBox(key: ValueKey<String>('trip-active'), height: 0),
              ),
              if (!trip.done && trip.leftCents < 0)
                _BudgetRecoveryCard(
                  trip: trip,
                  suggestions: savingSuggestions,
                  onReduce: (Item item) => _changeQuantity(trip, item, -1),
                ),
              if (recentProducts.isNotEmpty) ...<Widget>[
                const SizedBox(height: 18),
                Row(
                  children: <Widget>[
                    const Expanded(
                      child: Text(
                        'ADD AGAIN',
                        style: TextStyle(
                          color: kTag,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ),
                    Text(
                      'From your price history',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 9),
                SizedBox(
                  height: 105,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: recentProducts.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 9),
                    itemBuilder: (BuildContext context, int index) {
                      final PriceRecord record = recentProducts[index];
                      return _RecentProductCard(
                        record: record,
                        onAdd: () => _quickAdd(trip, record),
                      );
                    },
                  ),
                ),
              ],
              const SizedBox(height: 22),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: <Widget>[
                  Text('SHOPPING CART (${trip.itemCount})', style: theme.textTheme.labelLarge?.copyWith(letterSpacing: 1.2, color: theme.colorScheme.onSurfaceVariant, fontWeight: FontWeight.w800)),
                  Text(peso(trip.spentCents), style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                ],
              ),
              const SizedBox(height: 8),
              if (trip.items.isEmpty)
                _EmptyCart(done: trip.done)
              else ...<Widget>[
                TextField(
                  controller: _itemSearchController,
                  onChanged: (String value) => setState(() => _itemQuery = value),
                  decoration: InputDecoration(
                    hintText: 'Find an item in this cart',
                    prefixIcon: const Icon(Icons.search_rounded),
                    suffixIcon: _itemQuery.isEmpty
                        ? null
                        : IconButton(
                            tooltip: 'Clear item search',
                            onPressed: () {
                              _itemSearchController.clear();
                              setState(() => _itemQuery = '');
                            },
                            icon: const Icon(Icons.close_rounded),
                          ),
                  ),
                ),
                const SizedBox(height: 9),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: categories.map((String category) => Padding(
                      padding: const EdgeInsets.only(right: 7),
                      child: ChoiceChip(
                        label: Text(category),
                        selected: selectedCategory == category,
                        onSelected: (_) => setState(() => _categoryFilter = category),
                      ),
                    )).toList(),
                  ),
                ),
                const SizedBox(height: 8),
                if (visibleItems.isEmpty)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF2F0),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Text('No items match this search or category.', textAlign: TextAlign.center),
                  )
                else
                  ...visibleItems.map((Item i) => _ItemRow(
                        item: i,
                        editable: !trip.done,
                        onTap: trip.done ? null : () => _openItemSheet(trip, i, isNew: false),
                        onMinus: () => _changeQuantity(trip, i, -1),
                        onPlus: () => _changeQuantity(trip, i, 1),
                      )),
              ],
              if (trip.done)
                Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: OutlinedButton(
                    onPressed: () => widget.store.updateTrip(trip, done: false),
                    child: const Text('Reopen trip'),
                  ),
                ),
              const SizedBox(height: 90),
            ],
          ),
          bottomNavigationBar: trip.done
              ? null
              : SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: SizedBox(
                            height: 56,
                            child: FilledButton.icon(
                              onPressed: _busy ? null : () => _scan(trip),
                              icon: _busy
                                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 3))
                                  : const Icon(Icons.photo_camera_outlined),
                              label: Text(_busy ? 'Reading price tag…' : 'Scan price tag', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        SizedBox(
                          width: 48,
                          height: 56,
                          child: IconButton.filledTonal(
                            tooltip: 'Choose photo from gallery',
                            onPressed: _busy ? null : () => _scan(trip, fromGallery: true),
                            icon: const Icon(Icons.photo_library_outlined),
                          ),
                        ),
                        const SizedBox(width: 6),
                        SizedBox(
                          width: 52,
                          height: 56,
                          child: IconButton.filledTonal(
                            tooltip: 'Add item by hand',
                            onPressed: _busy ? null : () => _openItemSheet(trip, Item(id: newId(), name: '', priceCents: 0), isNew: true),
                            icon: const Icon(Icons.add),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        );
      },
    );
  }
}


class _RecentProductCard extends StatelessWidget {
  const _RecentProductCard({
    required this.record,
    required this.onAdd,
  });

  final PriceRecord record;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 154,
      padding: const EdgeInsets.fromLTRB(11, 10, 8, 8),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF2F0),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFFFD5D0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            record.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: kTag,
              fontWeight: FontWeight.w800,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            peso(record.priceCents),
            style: const TextStyle(
              color: kTag,
              fontWeight: FontWeight.w900,
              fontSize: 15,
            ),
          ),
          Text(
            'Last saved ${showDate(record.recordedAt)}',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Color(0xFF777989),
              fontSize: 9,
            ),
          ),
          const Spacer(),
          Align(
            alignment: Alignment.centerRight,
            child: SizedBox(
              height: 30,
              child: FilledButton.tonalIcon(
                onPressed: onAdd,
                icon: const Icon(Icons.add_rounded, size: 16),
                label: const Text('Add'),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  visualDensity: VisualDensity.compact,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BudgetRecoveryCard extends StatelessWidget {
  const _BudgetRecoveryCard({
    required this.trip,
    required this.suggestions,
    required this.onReduce,
  });

  final Trip trip;
  final List<BudgetSavingSuggestion> suggestions;
  final ValueChanged<Item> onReduce;

  @override
  Widget build(BuildContext context) {
    final List<BudgetSavingSuggestion> visible = suggestions.take(3).toList();

    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF2F0),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFFC9C4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(Icons.tips_and_updates_outlined, color: kOver),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'BUDGET RECOVERY',
                  style: TextStyle(
                    color: kTag,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                    fontSize: 12,
                  ),
                ),
              ),
              Text(
                '-${peso(-trip.leftCents)}',
                style: const TextStyle(
                  color: kOver,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 5),
          const Text(
            'You are over budget. These are optional ways to lower the cart total. Nothing changes until you tap a suggestion.',
            style: TextStyle(color: kTag, fontSize: 12, height: 1.35),
          ),
          const SizedBox(height: 10),
          if (visible.isEmpty)
            const Text(
              'No multi-quantity items to adjust. Review item prices or edit your budget.',
              style: TextStyle(color: kTag, fontWeight: FontWeight.w600),
            )
          else
            ...visible.map((BudgetSavingSuggestion suggestion) {
              final Item item = suggestion.item;
              return Padding(
                padding: const EdgeInsets.only(top: 7),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            item.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: kTag,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Text(
                            'Reduce ${item.qty} to ${item.qty - 1}',
                            style: const TextStyle(
                              color: Color(0xFF777989),
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton(
                      onPressed: () => onReduce(item),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: kTag,
                        side: const BorderSide(color: Color(0xFFFFA9A2)),
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        visualDensity: VisualDensity.compact,
                      ),
                      child: Text('Save ${peso(suggestion.savingsCents)}'),
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _TagCard extends StatelessWidget {
  const _TagCard({required this.trip, required this.onTap});
  final Trip trip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final int left = trip.leftCents;
    final double used = trip.budgetCents > 0 ? trip.spentCents / trip.budgetCents : 1.0;
    final bool over = left < 0;
    final bool warn = !over && used >= 0.8;
    final Color accent = over ? kOver : (warn ? kWarn : kOnTag);
    return Material(
      color: kTag,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(over ? 'OVER BUDGET' : 'BUDGET LEFT', style: const TextStyle(color: kOnTag, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.4)),
                  const Row(
                    children: <Widget>[
                      Icon(Icons.edit_outlined, size: 14, color: kOnTag),
                      SizedBox(width: 4),
                      Text('EDIT', style: TextStyle(color: kOnTag, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 6),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(peso(left), style: TextStyle(color: over ? kOver : kOnTag, fontSize: 64, height: 1.05, fontWeight: FontWeight.w900)),
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(999),
                child: TweenAnimationBuilder<double>(
                  tween: Tween<double>(
                    begin: 0,
                    end: used.clamp(0.0, 1.0).toDouble(),
                  ),
                  duration: const Duration(milliseconds: 420),
                  curve: Curves.easeOutCubic,
                  builder: (BuildContext context, double value, Widget? child) =>
                      LinearProgressIndicator(
                    value: value,
                    minHeight: 10,
                    backgroundColor: kTagTrack,
                    valueColor: AlwaysStoppedAnimation<Color>(accent),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Flexible(child: Text('Used ${(used * 100).round()}% of ${peso(trip.budgetCents)}', style: const TextStyle(color: kOnTag, fontWeight: FontWeight.w600))),
                  const SizedBox(width: 8),
                  Text('In cart ${peso(trip.spentCents)}', style: const TextStyle(color: kOnTag, fontWeight: FontWeight.w800)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ItemRow extends StatelessWidget {
  const _ItemRow({
    required this.item,
    required this.editable,
    required this.onTap,
    required this.onMinus,
    required this.onPlus,
  });
  final Item item;
  final bool editable;
  final VoidCallback? onTap;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme cs = theme.colorScheme;
    final String initial = item.name.trim().isEmpty ? '?' : item.name.trim()[0].toUpperCase();
    Widget thumb = Center(child: Text(initial, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: cs.onSurfaceVariant)));
    final String? img = item.imagePath;
    if (img != null) {
      thumb = Image.file(
        File(img),
        fit: BoxFit.cover,
        cacheWidth: 144,
        errorBuilder: (BuildContext c, Object e, StackTrace? s) => Center(child: Text(initial, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: cs.onSurfaceVariant))),
      );
    }
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      color: cs.surfaceContainer,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: cs.outlineVariant)),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Container(width: 52, height: 52, color: cs.surfaceContainerHighest, child: thumb),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(item.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, height: 1.2)),
                    const SizedBox(height: 4),
                    Text(
                      item.qty > 1 ? '${item.cat} · ${peso(item.priceCents)} each' : item.cat,
                      style: theme.textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(peso(item.lineCents), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  if (editable)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        _StepBtn(icon: Icons.remove, onTap: item.qty > 1 ? onMinus : null),
                        SizedBox(width: 26, child: Text('${item.qty}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800))),
                        _StepBtn(icon: Icons.add, onTap: onPlus),
                      ],
                    )
                  else
                    Text('× ${item.qty}', style: theme.textTheme.bodySmall),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StepBtn extends StatelessWidget {
  const _StepBtn({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkResponse(
      onTap: onTap,
      radius: 22,
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: Icon(icon, size: 18, color: onTap == null ? Theme.of(context).disabledColor : null),
      ),
    );
  }
}

class _EmptyCart extends StatelessWidget {
  const _EmptyCart({required this.done});
  final bool done;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.outlineVariant, width: 1.5),
      ),
      child: Column(
        children: <Widget>[
          Text('Your cart is empty', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(
            done ? 'Nothing was added on this trip.' : 'Tap Scan price tag and frame the shelf tag. Or add an item by hand with the + button.',
            textAlign: TextAlign.center,
            style: TextStyle(color: theme.colorScheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}
