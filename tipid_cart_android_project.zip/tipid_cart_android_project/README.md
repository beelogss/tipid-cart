# Tipid Cart

Flutter Android shopping-budget tracker. Scans a photo of a shelf price tag using on-device ML Kit text recognition; barcode lookup is not implemented in this version.

## Build an APK using only your Android phone

1. Create a repository on GitHub and upload this project with the same folder structure (especially `lib/` and `.github/workflows/`).
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab and select **Build APK**. If it has not run automatically, tap **Run workflow**.
4. Open the completed run and find **Artifacts** at the bottom. Download `tipid-cart-apk` and extract it to get `app-release.apk`.
5. Open the APK on your phone and allow your browser or file manager to install unknown apps if Android asks.

The workflow builds the APK in GitHub's cloud; no PC is needed. The first build can take several minutes. If it fails, open the run and share the first relevant red error lines.
