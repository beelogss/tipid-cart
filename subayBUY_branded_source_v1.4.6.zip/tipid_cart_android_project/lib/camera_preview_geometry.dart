import 'dart:math' as math;

/// Returns the scale needed to fill a viewport without distorting its aspect ratio.
/// Both ratios are expressed as width / height.
double cameraPreviewCoverScale({
  required double viewportAspectRatio,
  required double previewAspectRatio,
}) {
  if (!viewportAspectRatio.isFinite ||
      !previewAspectRatio.isFinite ||
      viewportAspectRatio <= 0 ||
      previewAspectRatio <= 0) {
    return 1.0;
  }

  return math.max(
    previewAspectRatio / viewportAspectRatio,
    viewportAspectRatio / previewAspectRatio,
  ).toDouble();
}
