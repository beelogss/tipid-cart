import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'models.dart';

class ItemSheetResult {
  const ItemSheetResult({
    required this.name,
    required this.priceCents,
    required this.qty,
    required this.cat,
    this.delete = false,
  });
  final String name;
  final int priceCents;
  final int qty;
  final String cat;
  final bool delete;
}

Future<ItemSheetResult?> showItemSheet(
  BuildContext context, {
  required Item item,
  required bool isNew,
  String? note,
}) {
  return showModalBottomSheet<ItemSheetResult>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (BuildContext ctx) => _ItemSheet(item: item, isNew: isNew, note: note),
  );
}

class _ItemSheet extends StatefulWidget {
  const _ItemSheet({required this.item, required this.isNew, this.note});
  final Item item;
  final bool isNew;
  final String? note;

  @override
  State<_ItemSheet> createState() => _ItemSheetState();
}

class _ItemSheetState extends State<_ItemSheet> {
  late final TextEditingController _name;
  late final TextEditingController _price;
  late int _qty;
  late String _cat;
  String? _err;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.item.name);
    _price = TextEditingController(
      text: widget.item.priceCents > 0 ? (widget.item.priceCents / 100).toStringAsFixed(2) : '',
    );
    _qty = widget.item.qty;
    _cat = kCats.contains(widget.item.cat) ? widget.item.cat : 'Other';
  }

  @override
  void dispose() {
    _name.dispose();
    _price.dispose();
    super.dispose();
  }

  void _save() {
    final int? cents = parseCents(_price.text);
    if (cents == null) {
      setState(() => _err = 'Enter the price, for example 79.75.');
      return;
    }
    final String n = _name.text.trim();
    Navigator.of(context).pop(
      ItemSheetResult(name: n.isEmpty ? 'Item' : n, priceCents: cents, qty: _qty, cat: _cat),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(widget.isNew ? 'Add item' : 'Edit item', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            if (widget.note != null) ...<Widget>[
              const SizedBox(height: 8),
              Text(widget.note!, style: TextStyle(color: theme.colorScheme.error)),
            ],
            const SizedBox(height: 16),
            TextField(
              controller: _name,
              textCapitalization: TextCapitalization.sentences,
              maxLength: 60,
              decoration: const InputDecoration(labelText: 'Name', border: OutlineInputBorder(), counterText: ''),
            ),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _price,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
                    decoration: const InputDecoration(labelText: 'Price (each)', prefixText: '₱ ', border: OutlineInputBorder()),
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  height: 56,
                  decoration: BoxDecoration(
                    border: Border.all(color: theme.colorScheme.outline),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Row(
                    children: <Widget>[
                      IconButton(
                        tooltip: 'Less',
                        icon: const Icon(Icons.remove),
                        onPressed: _qty > 1 ? () => setState(() => _qty--) : null,
                      ),
                      SizedBox(width: 24, child: Text('$_qty', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
                      IconButton(
                        tooltip: 'More',
                        icon: const Icon(Icons.add),
                        onPressed: _qty < 99 ? () => setState(() => _qty++) : null,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: kCats
                  .map((String c) => ChoiceChip(
                        label: Text(c),
                        selected: _cat == c,
                        onSelected: (bool _) => setState(() => _cat = c),
                      ))
                  .toList(),
            ),
            if (_err != null) ...<Widget>[
              const SizedBox(height: 10),
              Text(_err!, style: TextStyle(color: theme.colorScheme.error)),
            ],
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton(onPressed: _save, child: Text(widget.isNew ? 'Add to cart' : 'Save')),
            ),
            if (!widget.isNew)
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () => Navigator.of(context).pop(
                    ItemSheetResult(name: widget.item.name, priceCents: widget.item.priceCents, qty: widget.item.qty, cat: widget.item.cat, delete: true),
                  ),
                  child: Text('Remove from cart', style: TextStyle(color: theme.colorScheme.error)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class TripSheetResult {
  const TripSheetResult({required this.name, required this.budgetCents, this.delete = false});
  final String name;
  final int budgetCents;
  final bool delete;
}

/// New trip when [trip] is null; otherwise edits the name and budget.
Future<TripSheetResult?> showTripSheet(BuildContext context, {String? name, int? budgetCents}) {
  return showModalBottomSheet<TripSheetResult>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (BuildContext ctx) => _TripSheet(initialName: name, initialBudget: budgetCents),
  );
}

class _TripSheet extends StatefulWidget {
  const _TripSheet({this.initialName, this.initialBudget});
  final String? initialName;
  final int? initialBudget;

  @override
  State<_TripSheet> createState() => _TripSheetState();
}

class _TripSheetState extends State<_TripSheet> {
  late final TextEditingController _name;
  late final TextEditingController _budget;
  String? _err;

  bool get _isNew => widget.initialName == null;

  @override
  void initState() {
    super.initState();
    final DateTime d = DateTime.now();
    _name = TextEditingController(text: widget.initialName ?? 'Shop ${showDate(d).split(',').first}');
    _budget = TextEditingController(
      text: widget.initialBudget == null ? '' : (widget.initialBudget! / 100).toStringAsFixed(widget.initialBudget! % 100 == 0 ? 0 : 2),
    );
  }

  @override
  void dispose() {
    _name.dispose();
    _budget.dispose();
    super.dispose();
  }

  void _save() {
    final int? cents = parseCents(_budget.text);
    if (cents == null || cents <= 0) {
      setState(() => _err = 'Enter a budget greater than zero.');
      return;
    }
    final String n = _name.text.trim();
    Navigator.of(context).pop(TripSheetResult(name: n.isEmpty ? 'Shopping trip' : n, budgetCents: cents));
  }

  Future<void> _confirmDelete() async {
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: const Text('Delete this trip?'),
        content: const Text('The trip and its cart items will be removed.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok == true && mounted) {
      Navigator.of(context).pop(const TripSheetResult(name: '', budgetCents: 0, delete: true));
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(_isNew ? 'New trip' : 'Edit budget', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            TextField(
              controller: _name,
              maxLength: 40,
              decoration: const InputDecoration(labelText: 'Trip name', border: OutlineInputBorder(), counterText: ''),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _budget,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
              decoration: const InputDecoration(labelText: 'Budget', prefixText: '₱ ', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: <int>[500, 1000, 2000, 3000, 5000]
                  .map((int v) => ActionChip(
                        label: Text('₱${v >= 1000 ? '${v ~/ 1000},000' : v}'),
                        onPressed: () => setState(() => _budget.text = '$v'),
                      ))
                  .toList(),
            ),
            if (_err != null) ...<Widget>[
              const SizedBox(height: 10),
              Text(_err!, style: TextStyle(color: theme.colorScheme.error)),
            ],
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton(onPressed: _save, child: Text(_isNew ? 'Start shopping' : 'Save')),
            ),
            if (!_isNew)
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: _confirmDelete,
                  child: Text('Delete trip', style: TextStyle(color: theme.colorScheme.error)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
