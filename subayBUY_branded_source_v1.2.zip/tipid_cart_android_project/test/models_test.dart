import 'package:flutter_test/flutter_test.dart';
import 'package:tipid_cart/models.dart';

void main() {
  group('Money helpers', () {
    test('parses prices into centavos', () {
      expect(parseCents('79.75'), 7975);
      expect(parseCents('1,250.00'), 125000);
      expect(parseCents('0.50'), 50);
    });

    test('rejects invalid prices', () {
      expect(parseCents(''), isNull);
      expect(parseCents('abc'), isNull);
      expect(parseCents('-5'), isNull);
    });

    test('formats pesos with two decimal places', () {
      expect(peso(7975), '₱79.75');
      expect(peso(0), '₱0.00');
      expect(peso(-12550), '-₱125.50');
    });
  });

  test('trip totals include item quantities', () {
    final Trip trip = Trip(
      id: 'test',
      name: 'Test trip',
      date: DateTime(2026, 10, 31),
      budgetCents: 20000,
      items: <Item>[
        Item(id: 'a', name: 'Milk', priceCents: 5000, qty: 2),
        Item(id: 'b', name: 'Bread', priceCents: 3500),
      ],
    );
    expect(trip.spentCents, 13500);
    expect(trip.leftCents, 6500);
    expect(trip.itemCount, 3);
  });
}
