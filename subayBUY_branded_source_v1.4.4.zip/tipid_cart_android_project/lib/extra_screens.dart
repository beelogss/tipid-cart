import 'package:flutter/material.dart';

import 'models.dart';
import 'store.dart';
import 'notifications.dart';

const Color _coral = Color(0xFFFF525F);
const Color _navy = Color(0xFF252839);
const Color _soft = Color(0xFFFFF2F0);

class WishlistScreen extends StatefulWidget {
  const WishlistScreen({super.key, required this.store});
  final Store store;

  @override
  State<WishlistScreen> createState() => _WishlistScreenState();
}

class _WishlistScreenState extends State<WishlistScreen> {
  Future<void> _editEntry({WishlistEntry? entry}) async {
    // Use a dedicated route rather than a modal bottom sheet. The editor
    // returns a value; the Store is updated only after that route is gone.
    final WishlistEntry? result = await Navigator.of(context).push<WishlistEntry>(
      MaterialPageRoute<WishlistEntry>(
        builder: (_) => WishlistEditorScreen(entry: entry),
      ),
    );
    if (result == null || !mounted) return;

    if (entry == null) {
      widget.store.addWishlistEntry(result);
    } else {
      widget.store.updateWishlistEntry(
        entry,
        name: result.name,
        estimatedPriceCents: result.estimatedPriceCents,
        category: result.category,
      );
    }
  }

  Future<void> _addToTrip(WishlistEntry entry) async {
    final List<Trip> active = widget.store.trips.where((Trip t) => !t.done).toList();
    if (active.isEmpty) {
      showTransientNotice(ScaffoldMessenger.of(context), 'Create an active shopping trip first.');
      return;
    }
    final Trip? selected = await showDialog<Trip>(
      context: context,
      builder: (BuildContext context) => SimpleDialog(
        title: const Text('Add to which trip?'),
        children: active.map((Trip trip) => SimpleDialogOption(
          onPressed: () => Navigator.of(context).pop(trip),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(children: <Widget>[const Icon(Icons.shopping_cart_outlined, color: _coral), const SizedBox(width: 10), Expanded(child: Text(trip.name)), Text(peso(trip.leftCents), style: const TextStyle(fontWeight: FontWeight.w700))]),
          ),
        )).toList(),
      ),
    );
    if (selected == null || !mounted) return;
    widget.store.addItem(selected, Item(id: newId(), name: entry.name, priceCents: entry.estimatedPriceCents, cat: entry.category));
    showTransientNotice(ScaffoldMessenger.of(context), '${entry.name} added to ${selected.name}.');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Wishlist')),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _editEntry(),
          backgroundColor: _coral,
          foregroundColor: Colors.white,
          icon: const Icon(Icons.add),
          label: const Text('Add item'),
        ),
        body: ListenableBuilder(
          listenable: widget.store,
          builder: (BuildContext context, Widget? child) {
            if (widget.store.wishlist.isEmpty) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
                    Container(width: 76, height: 76, decoration: const BoxDecoration(color: _soft, shape: BoxShape.circle), child: const Icon(Icons.favorite_border_rounded, color: _coral, size: 38)),
                    const SizedBox(height: 14),
                    const Text('Plan before you shop', style: TextStyle(color: _navy, fontSize: 20, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 7),
                    const Text('Save products you want to buy, add estimated prices, then move them into an active shopping trip when you are ready.', textAlign: TextAlign.center, style: TextStyle(color: _navy)),
                    const SizedBox(height: 14),
                    FilledButton.icon(onPressed: () => _editEntry(), icon: const Icon(Icons.add), label: const Text('Add your first item')),
                  ]),
                ),
              );
            }
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
              itemCount: widget.store.wishlist.length,
              separatorBuilder: (_, __) => const SizedBox(height: 9),
              itemBuilder: (BuildContext context, int index) {
                final WishlistEntry entry = widget.store.wishlist[index];
                return Container(
                  padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFFFD5D0))),
                  child: Row(children: <Widget>[
                    Container(width: 42, height: 42, decoration: BoxDecoration(color: _soft, borderRadius: BorderRadius.circular(13)), child: const Icon(Icons.favorite_rounded, color: _coral)),
                    const SizedBox(width: 11),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                      Text(entry.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _navy, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 3),
                      Text('${entry.category} · ${entry.estimatedPriceCents > 0 ? peso(entry.estimatedPriceCents) : 'Price not set'}', style: const TextStyle(color: Color(0xFF777989), fontSize: 12)),
                    ])),
                    PopupMenuButton<String>(
                      onSelected: (String action) {
                        if (action == 'add') _addToTrip(entry);
                        if (action == 'edit') _editEntry(entry: entry);
                        if (action == 'delete') widget.store.removeWishlistEntry(entry.id);
                      },
                      itemBuilder: (_) => const <PopupMenuEntry<String>>[
                        PopupMenuItem(value: 'add', child: Text('Add to active trip')),
                        PopupMenuItem(value: 'edit', child: Text('Edit item')),
                        PopupMenuItem(value: 'delete', child: Text('Remove')),
                      ],
                    ),
                  ]),
                );
              },
            );
          },
        ),
      );
}


/// A full-page wishlist editor. It never mutates Store while its route is
/// mounted; it returns a value to WishlistScreen, which saves after pop.
class WishlistEditorScreen extends StatefulWidget {
  const WishlistEditorScreen({super.key, this.entry});
  final WishlistEntry? entry;

  @override
  State<WishlistEditorScreen> createState() => _WishlistEditorScreenState();
}

class _WishlistEditorScreenState extends State<WishlistEditorScreen> {
  late final TextEditingController _nameController;
  late final TextEditingController _priceController;
  late String _category;
  String? _nameError;
  String? _priceError;

  @override
  void initState() {
    super.initState();
    final WishlistEntry? entry = widget.entry;
    _nameController = TextEditingController(text: entry?.name ?? '');
    _priceController = TextEditingController(
      text: entry == null || entry.estimatedPriceCents == 0
          ? ''
          : (entry.estimatedPriceCents / 100).toStringAsFixed(2),
    );
    _category = entry != null && kCats.contains(entry.category)
        ? entry.category
        : 'Grocery';
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  void _save() {
    final String name = _nameController.text.trim();
    final String priceText = _priceController.text.trim();
    final int? parsedPrice = priceText.isEmpty ? 0 : parseCents(priceText);

    setState(() {
      _nameError = name.isEmpty ? 'Enter a product name.' : null;
      _priceError = parsedPrice == null ? 'Enter a valid price.' : null;
    });
    if (_nameError != null || _priceError != null || parsedPrice == null) return;

    FocusScope.of(context).unfocus();
    final WishlistEntry? old = widget.entry;
    Navigator.of(context).pop<WishlistEntry>(
      WishlistEntry(
        id: old?.id ?? newId(),
        name: name,
        estimatedPriceCents: parsedPrice,
        category: _category,
        createdAt: old?.createdAt,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool editing = widget.entry != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(editing ? 'Edit wishlist item' : 'Add to wishlist'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
          children: <Widget>[
            Container(
              width: 60,
              height: 60,
              alignment: Alignment.center,
              decoration: const BoxDecoration(color: _soft, shape: BoxShape.circle),
              child: const Icon(Icons.favorite_rounded, color: _coral, size: 30),
            ),
            const SizedBox(height: 18),
            Text(
              editing ? 'Update your planned purchase' : 'Plan before you shop',
              style: const TextStyle(color: _navy, fontSize: 21, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 7),
            const Text(
              'Save the product and its estimated price. You can add it to an active shopping trip later.',
              style: TextStyle(color: Color(0xFF777989), height: 1.4),
            ),
            const SizedBox(height: 22),
            TextField(
              key: const ValueKey<String>('wishlist-name-field'),
              controller: _nameController,
              textCapitalization: TextCapitalization.sentences,
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(
                labelText: 'Product name',
                hintText: 'e.g. Laundry detergent',
                errorText: _nameError,
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              key: const ValueKey<String>('wishlist-price-field'),
              controller: _priceController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _save(),
              decoration: InputDecoration(
                labelText: 'Estimated price (₱)',
                hintText: 'Optional',
                errorText: _priceError,
              ),
            ),
            const SizedBox(height: 14),
            InputDecorator(
              decoration: const InputDecoration(labelText: 'Category'),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _category,
                  isExpanded: true,
                  items: kCats
                      .map((String category) => DropdownMenuItem<String>(
                            value: category,
                            child: Text(category),
                          ))
                      .toList(),
                  onChanged: (String? value) {
                    if (value != null) setState(() => _category = value);
                  },
                ),
              ),
            ),
            const SizedBox(height: 28),
            SizedBox(
              height: 54,
              child: FilledButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.save_outlined),
                label: Text(editing ? 'Save changes' : 'Save to wishlist'),
                style: FilledButton.styleFrom(
                  backgroundColor: _coral,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class InsightsScreen extends StatelessWidget {
  const InsightsScreen({super.key, required this.store});
  final Store store;

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Spending insights'),
            bottom: const TabBar(tabs: <Widget>[Tab(text: 'Overview'), Tab(text: 'Price history'), Tab(text: 'Unit price')]),
          ),
          body: ListenableBuilder(
            listenable: store,
            builder: (BuildContext context, Widget? child) => TabBarView(
              children: <Widget>[
                _SpendingOverview(store: store),
                _PriceHistoryView(records: store.priceHistory),
                const _UnitPriceCalculator(),
              ],
            ),
          ),
        ),
      );
}

class _SpendingOverview extends StatelessWidget {
  const _SpendingOverview({required this.store});
  final Store store;

  @override
  Widget build(BuildContext context) {
    final List<Trip> trips = store.trips;
    final int total = trips.fold<int>(0, (int sum, Trip trip) => sum + trip.spentCents);
    final int average = trips.isEmpty ? 0 : total ~/ trips.length;
    final Map<String, int> categories = <String, int>{};
    for (final Trip trip in trips) {
      for (final Item item in trip.items) {
        categories[item.cat] = (categories[item.cat] ?? 0) + item.lineCents;
      }
    }
    final List<MapEntry<String, int>> ranked = categories.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final DateTime today = DateTime.now();
    final List<_MonthSpend> months = List<_MonthSpend>.generate(6, (int index) {
      final DateTime month = DateTime(today.year, today.month - (5 - index));
      final int cents = trips.where((Trip trip) => trip.date.year == month.year && trip.date.month == month.month).fold<int>(0, (int sum, Trip trip) => sum + trip.spentCents);
      return _MonthSpend(month, cents);
    });
    final int maxMonth = months.fold<int>(0, (int max, _MonthSpend m) => m.cents > max ? m.cents : max);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Row(children: <Widget>[
          Expanded(child: _MetricCard(label: 'TOTAL SPENT', value: peso(total), icon: Icons.payments_outlined)),
          const SizedBox(width: 9),
          Expanded(child: _MetricCard(label: 'AVERAGE / TRIP', value: peso(average), icon: Icons.receipt_long_outlined)),
        ]),
        const SizedBox(height: 18),
        const Text('SPENDING BY TRIP MONTH', style: TextStyle(color: _navy, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFFFD5D0))),
          child: Column(children: months.map((_MonthSpend m) {
            final double fraction = maxMonth == 0 ? 0 : m.cents / maxMonth;
            const List<String> monthNames = <String>['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 7),
              child: Row(children: <Widget>[
                SizedBox(width: 34, child: Text(monthNames[m.date.month - 1], style: const TextStyle(color: _navy, fontSize: 12, fontWeight: FontWeight.w700))),
                const SizedBox(width: 8),
                Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: fraction, minHeight: 10, backgroundColor: _soft, color: _coral))),
                const SizedBox(width: 9),
                SizedBox(width: 88, child: Text(peso(m.cents), textAlign: TextAlign.end, style: const TextStyle(color: _navy, fontSize: 11, fontWeight: FontWeight.w700))),
              ]),
            );
          }).toList()),
        ),
        const SizedBox(height: 20),
        const Text('SPENDING BY CATEGORY', style: TextStyle(color: _navy, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
        const SizedBox(height: 10),
        if (ranked.isEmpty)
          const _EmptyInsight(message: 'Add items to your shopping trips to see category spending.')
        else
          ...ranked.map((MapEntry<String, int> entry) {
            final double fraction = total <= 0 ? 0 : entry.value / total;
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Column(children: <Widget>[
                Row(children: <Widget>[Expanded(child: Text(entry.key, style: const TextStyle(color: _navy, fontWeight: FontWeight.w700))), Text(peso(entry.value), style: const TextStyle(color: _navy, fontWeight: FontWeight.w800))]),
                const SizedBox(height: 6),
                ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: fraction, minHeight: 9, backgroundColor: _soft, color: _coral)),
              ]),
            );
          }),
      ],
    );
  }
}

class _MonthSpend {
  const _MonthSpend(this.date, this.cents);
  final DateTime date;
  final int cents;
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.label, required this.value, required this.icon});
  final String label;
  final String value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: _soft, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFFFD5D0))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Icon(icon, color: _coral), const SizedBox(height: 9),
          Text(label, style: const TextStyle(color: _navy, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 0.9)),
          const SizedBox(height: 4),
          FittedBox(fit: BoxFit.scaleDown, child: Text(value, style: const TextStyle(color: _navy, fontSize: 20, fontWeight: FontWeight.w900))),
        ]),
      );
}

class _PriceHistoryView extends StatelessWidget {
  const _PriceHistoryView({required this.records});
  final List<PriceRecord> records;

  @override
  Widget build(BuildContext context) {
    final Map<String, List<PriceRecord>> grouped = <String, List<PriceRecord>>{};
    for (final PriceRecord record in records) {
      final String key = record.name.trim().toLowerCase();
      if (key.isEmpty) continue;
      grouped.putIfAbsent(key, () => <PriceRecord>[]).add(record);
    }
    final List<List<PriceRecord>> groups = grouped.values.toList()
      ..forEach((List<PriceRecord> list) => list.sort((PriceRecord a, PriceRecord b) => b.recordedAt.compareTo(a.recordedAt)))
      ..sort((List<PriceRecord> a, List<PriceRecord> b) => b.first.recordedAt.compareTo(a.first.recordedAt));
    if (groups.isEmpty) return const _EmptyInsight(message: 'Price history will appear after you add or update scanned and manual item prices.');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: groups.length,
      separatorBuilder: (_, __) => const SizedBox(height: 9),
      itemBuilder: (BuildContext context, int index) {
        final List<PriceRecord> history = groups[index];
        final PriceRecord latest = history.first;
        final PriceRecord? previous = history.length > 1 ? history[1] : null;
        final int? delta = previous == null ? null : latest.priceCents - previous.priceCents;
        final String change = delta == null ? 'First recorded price' : delta == 0 ? 'No change since previous entry' : '${delta > 0 ? 'Up' : 'Down'} ${peso(delta.abs())} since previous entry';
        final Color changeColor = delta == null || delta == 0 ? _navy : delta > 0 ? _coral : const Color(0xFF26845B);
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFFFD5D0))),
          child: Row(children: <Widget>[
            Container(width: 42, height: 42, decoration: BoxDecoration(color: _soft, borderRadius: BorderRadius.circular(13)), child: const Icon(Icons.price_change_outlined, color: _coral)),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              Text(latest.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _navy, fontWeight: FontWeight.w800)),
              const SizedBox(height: 3),
              Text('${latest.category} · ${showDate(latest.recordedAt)}', style: const TextStyle(color: Color(0xFF777989), fontSize: 11)),
              const SizedBox(height: 3),
              Text(change, style: TextStyle(color: changeColor, fontSize: 11, fontWeight: FontWeight.w700)),
            ])),
            const SizedBox(width: 8),
            Text(peso(latest.priceCents), style: const TextStyle(color: _navy, fontWeight: FontWeight.w900)),
          ]),
        );
      },
    );
  }
}

class _EmptyInsight extends StatelessWidget {
  const _EmptyInsight({required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: _soft, borderRadius: BorderRadius.circular(16)),
        child: Text(message, textAlign: TextAlign.center, style: const TextStyle(color: _navy)),
      );
}


/// Returns unit price in centavos per 100 g/ml, or per piece.
/// Package amounts are normalized to g, ml, or pieces before comparison.
int? calculateUnitPriceCents({
  required int packagePriceCents,
  required double amount,
  required String unit,
}) {
  if (packagePriceCents <= 0 || !amount.isFinite || amount <= 0) return null;
  final double baseAmount = switch (unit) {
    'kg' => amount * 1000,
    'L' => amount * 1000,
    'g' || 'ml' || 'pc' => amount,
    _ => double.nan,
  };
  if (!baseAmount.isFinite || baseAmount <= 0) return null;
  final double multiplier = unit == 'pc' ? 1 : 100;
  return (packagePriceCents * multiplier / baseAmount).round();
}

class _UnitPriceCalculator extends StatefulWidget {
  const _UnitPriceCalculator();

  @override
  State<_UnitPriceCalculator> createState() => _UnitPriceCalculatorState();
}

class _UnitPriceCalculatorState extends State<_UnitPriceCalculator> {
  final TextEditingController _priceA = TextEditingController();
  final TextEditingController _amountA = TextEditingController();
  final TextEditingController _priceB = TextEditingController();
  final TextEditingController _amountB = TextEditingController();
  String _unit = 'g';

  @override
  void dispose() {
    _priceA.dispose();
    _amountA.dispose();
    _priceB.dispose();
    _amountB.dispose();
    super.dispose();
  }

  int? _unitPrice(TextEditingController price, TextEditingController amount) {
    final int? cents = parseCents(price.text);
    final double? quantity = double.tryParse(amount.text.trim().replaceAll(',', ''));
    if (cents == null || quantity == null) return null;
    return calculateUnitPriceCents(
      packagePriceCents: cents,
      amount: quantity,
      unit: _unit,
    );
  }

  String get _rateLabel => _unit == 'pc' ? 'per piece' : 'per 100 ${_unit == 'kg' || _unit == 'g' ? 'g' : 'ml'}';

  @override
  Widget build(BuildContext context) {
    final int? a = _unitPrice(_priceA, _amountA);
    final int? b = _unitPrice(_priceB, _amountB);
    final String? comparison = a == null || b == null
        ? null
        : a == b
            ? 'Both products have the same unit price.'
            : '${a < b ? 'Product A' : 'Product B'} is the better value by ${peso((a - b).abs())} $_rateLabel.';

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _soft,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFFFD5D0)),
          ),
          child: const Text(
            'Compare different pack sizes to see which product gives you more value for your money.',
            style: TextStyle(color: _navy, height: 1.35),
          ),
        ),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(
          initialValue: _unit,
          decoration: const InputDecoration(labelText: 'Package unit'),
          items: const <DropdownMenuItem<String>>[
            DropdownMenuItem(value: 'g', child: Text('Grams (g)')),
            DropdownMenuItem(value: 'kg', child: Text('Kilograms (kg)')),
            DropdownMenuItem(value: 'ml', child: Text('Milliliters (ml)')),
            DropdownMenuItem(value: 'L', child: Text('Liters (L)')),
            DropdownMenuItem(value: 'pc', child: Text('Pieces (pc)')),
          ],
          onChanged: (String? value) => setState(() => _unit = value ?? 'g'),
        ),
        const SizedBox(height: 14),
        _UnitProductInput(
          title: 'PRODUCT A',
          priceController: _priceA,
          amountController: _amountA,
          unit: _unit,
          unitPriceCents: a,
          onChanged: () => setState(() {}),
          rateLabel: _rateLabel,
        ),
        const SizedBox(height: 12),
        _UnitProductInput(
          title: 'PRODUCT B',
          priceController: _priceB,
          amountController: _amountB,
          unit: _unit,
          unitPriceCents: b,
          onChanged: () => setState(() {}),
          rateLabel: _rateLabel,
        ),
        if (comparison != null) ...<Widget>[
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFEAF6EF),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFB9DEC8)),
            ),
            child: Row(
              children: <Widget>[
                const Icon(Icons.check_circle_rounded, color: Color(0xFF26845B)),
                const SizedBox(width: 10),
                Expanded(child: Text(comparison, style: const TextStyle(color: _navy, fontWeight: FontWeight.w800))),
              ],
            ),
          ),
        ],
        const SizedBox(height: 12),
        TextButton.icon(
          onPressed: () {
            _priceA.clear();
            _amountA.clear();
            _priceB.clear();
            _amountB.clear();
            setState(() => _unit = 'g');
          },
          icon: const Icon(Icons.refresh_rounded),
          label: const Text('Reset comparison'),
        ),
      ],
    );
  }
}

class _UnitProductInput extends StatelessWidget {
  const _UnitProductInput({
    required this.title,
    required this.priceController,
    required this.amountController,
    required this.unit,
    required this.unitPriceCents,
    required this.onChanged,
    required this.rateLabel,
  });

  final String title;
  final TextEditingController priceController;
  final TextEditingController amountController;
  final String unit;
  final int? unitPriceCents;
  final VoidCallback onChanged;
  final String rateLabel;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFFFD5D0)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(title, style: const TextStyle(color: _navy, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
            const SizedBox(height: 10),
            Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: priceController,
                    onChanged: (_) => onChanged(),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'Package price', prefixText: '₱ '),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: amountController,
                    onChanged: (_) => onChanged(),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(labelText: 'Package size', suffixText: unit),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              unitPriceCents == null ? 'Enter a valid price and package size.' : '${peso(unitPriceCents!)} $rateLabel',
              style: const TextStyle(color: _coral, fontWeight: FontWeight.w900),
            ),
          ],
        ),
      );
}
