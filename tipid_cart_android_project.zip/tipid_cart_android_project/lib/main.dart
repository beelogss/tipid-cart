import 'package:flutter/material.dart';

import 'models.dart';
import 'store.dart';
import 'trip_screen.dart';
import 'sheets.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final Store store = Store();
  await store.load();
  runApp(TipidCartApp(store: store));
}

class TipidCartApp extends StatelessWidget {
  const TipidCartApp({super.key, required this.store});
  final Store store;

  ThemeData _theme(Brightness b) {
    final bool dark = b == Brightness.dark;
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B6B5F), brightness: b),
      scaffoldBackgroundColor: dark ? const Color(0xFF0D1412) : const Color(0xFFEEF2F0),
      appBarTheme: AppBarTheme(
        backgroundColor: dark ? const Color(0xFF0D1412) : const Color(0xFFEEF2F0),
        surfaceTintColor: Colors.transparent,
        scrolledUnderElevation: 0,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tipid Cart',
      debugShowCheckedModeBanner: false,
      theme: _theme(Brightness.light),
      darkTheme: _theme(Brightness.dark),
      themeMode: ThemeMode.system,
      home: HomeScreen(store: store),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.store});
  final Store store;

  Future<void> _newTrip(BuildContext context) async {
    final TripSheetResult? r = await showTripSheet(context);
    if (r == null || r.delete || !context.mounted) return;
    final Trip t = store.addTrip(r.name, r.budgetCents);
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => TripScreen(store: store, tripId: t.id)));
  }

  void _open(BuildContext context, Trip t) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => TripScreen(store: store, tripId: t.id)));
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: ListenableBuilder(
          listenable: store,
          builder: (BuildContext context, Widget? _) {
            final List<Trip> live = store.trips.where((Trip t) => !t.done).toList();
            final List<Trip> done = store.trips.where((Trip t) => t.done).toList();
            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Text('Tipid ', style: theme.textTheme.displaySmall?.copyWith(fontWeight: FontWeight.w900)),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(color: kTag, borderRadius: BorderRadius.circular(6)),
                      child: Text('Cart', style: theme.textTheme.displaySmall?.copyWith(fontWeight: FontWeight.w900, color: kOnTag)),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text('Set a budget. Scan price tags. See what is left.', style: TextStyle(color: theme.colorScheme.onSurfaceVariant)),
                const SizedBox(height: 18),
                SizedBox(
                  height: 52,
                  child: FilledButton.icon(
                    onPressed: () => _newTrip(context),
                    icon: const Icon(Icons.add),
                    label: const Text('New trip', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  ),
                ),
                if (live.isNotEmpty) ...<Widget>[
                  _SectionLabel('ACTIVE'),
                  ...live.map((Trip t) => _TripRow(trip: t, onTap: () => _open(context, t))),
                ],
                if (done.isNotEmpty) ...<Widget>[
                  _SectionLabel('PAST TRIPS'),
                  ...done.map((Trip t) => _TripRow(trip: t, onTap: () => _open(context, t))),
                ],
                if (store.trips.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 22),
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: theme.colorScheme.outlineVariant, width: 1.5),
                      ),
                      child: Column(
                        children: <Widget>[
                          Text('No trips yet', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          Text(
                            'Start a trip, enter your budget, then point the camera at a shelf price tag. The price goes into your cart and comes off what is left.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: theme.colorScheme.onSurfaceVariant),
                          ),
                          const SizedBox(height: 14),
                          OutlinedButton(
                            onPressed: () {
                              final Trip t = store.addTrip('Sample trip (examples)', 200000);
                              store.addSampleItems(t);
                              _open(context, t);
                            },
                            child: const Text('Try a sample trip'),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 24, 2, 8),
      child: Text(text, style: theme.textTheme.labelLarge?.copyWith(letterSpacing: 1.2, color: theme.colorScheme.onSurfaceVariant, fontWeight: FontWeight.w800)),
    );
  }
}

class _TripRow extends StatelessWidget {
  const _TripRow({required this.trip, required this.onTap});
  final Trip trip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme cs = theme.colorScheme;
    final int left = trip.leftCents;
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      color: cs.surfaceContainer,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: cs.outlineVariant)),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(trip.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 2),
                    Text(
                      '${showDate(trip.date)} · ${trip.itemCount} item${trip.itemCount == 1 ? '' : 's'}',
                      style: theme.textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(peso(left), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: left < 0 ? cs.error : null)),
                  Text('of ${peso(trip.budgetCents)}', style: theme.textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
