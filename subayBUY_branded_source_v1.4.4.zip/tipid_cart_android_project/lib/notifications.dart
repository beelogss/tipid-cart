import 'package:flutter/material.dart';

/// Shows a short notice that always has a finite timeout.
///
/// Undo is rendered as an ordinary button inside the content instead of
/// SnackBar.action. Flutter intentionally keeps action snackbars visible for
/// accessibility navigation, which can make an "Added" notice look permanent.
void showTransientNotice(
  ScaffoldMessengerState messenger,
  String message, {
  VoidCallback? onUndo,
  Duration duration = const Duration(seconds: 2),
}) {
  messenger.removeCurrentSnackBar();
  messenger.clearSnackBars();
  messenger.showSnackBar(
    SnackBar(
      behavior: SnackBarBehavior.floating,
      duration: duration,
      persist: false,
      dismissDirection: DismissDirection.horizontal,
      content: Row(
        children: <Widget>[
          Expanded(
            child: Text(
              message,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (onUndo != null) ...<Widget>[
            const SizedBox(width: 8),
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: const Color(0xFFFFBDB2),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                minimumSize: Size.zero,
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              onPressed: () {
                messenger.hideCurrentSnackBar();
                onUndo();
              },
              child: const Text('Undo'),
            ),
          ],
        ],
      ),
    ),
  );
}
