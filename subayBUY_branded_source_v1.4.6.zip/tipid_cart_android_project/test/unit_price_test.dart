import 'package:flutter_test/flutter_test.dart';
import 'package:tipid_cart/extra_screens.dart';

void main() {
  group('Unit price calculator', () {
    test('normalizes kilograms to grams', () {
      expect(
        calculateUnitPriceCents(packagePriceCents: 12000, amount: 1, unit: 'kg'),
        1200,
      );
    });

    test('normalizes liters to milliliters', () {
      expect(
        calculateUnitPriceCents(packagePriceCents: 9000, amount: 1, unit: 'L'),
        900,
      );
    });

    test('calculates cost per piece without multiplying by 100', () {
      expect(
        calculateUnitPriceCents(packagePriceCents: 12000, amount: 6, unit: 'pc'),
        2000,
      );
    });

    test('rejects invalid price or amount', () {
      expect(calculateUnitPriceCents(packagePriceCents: 0, amount: 1, unit: 'g'), isNull);
      expect(calculateUnitPriceCents(packagePriceCents: 1000, amount: 0, unit: 'g'), isNull);
      expect(calculateUnitPriceCents(packagePriceCents: 1000, amount: double.infinity, unit: 'g'), isNull);
    });
  });
}
