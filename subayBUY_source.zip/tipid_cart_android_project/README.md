# subayBUY

A shopping budget tracker. Set a budget, scan shelf price tags with the camera, and track purchases offline.

## Build on Android using GitHub Actions

Upload this source archive to the repository root, then add the workflow file `subayBUY-build.yml` under `.github/workflows/`. Run it from the Actions tab. The workflow builds a debug APK and uploads the APK as `subayBUY.apk` inside the `subayBUY-apk` artifact.

The app keeps the existing local storage key so the current data format is retained. The Android application ID should remain the same as the previous build for an in-place update; do not change the `--org` value in the workflow if your previous APK used a different application ID.
