import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tipid_cart/extra_screens.dart';
import 'package:tipid_cart/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  testWidgets('wishlist item can be added and saved without a modal route',
      (WidgetTester tester) async {
    final Store store = Store();
    await tester.pumpWidget(MaterialApp(home: WishlistScreen(store: store)));

    await tester.tap(find.text('Add your first item'));
    await tester.pumpAndSettle();
    expect(find.byType(WishlistEditorScreen), findsOneWidget);

    await tester.enterText(find.byKey(const ValueKey<String>('wishlist-name-field')), 'Fresh milk');
    await tester.enterText(find.byKey(const ValueKey<String>('wishlist-price-field')), '89.50');
    await tester.tap(find.text('Save to wishlist'));
    await tester.pumpAndSettle();

    expect(store.wishlist, hasLength(1));
    expect(store.wishlist.single.name, 'Fresh milk');
    expect(store.wishlist.single.estimatedPriceCents, 8950);
    expect(find.text('Fresh milk'), findsOneWidget);
  });
}
