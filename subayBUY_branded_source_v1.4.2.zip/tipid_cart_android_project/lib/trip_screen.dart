import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import 'built_in_camera_screen.dart';

import 'models.dart';
import 'scanner.dart';
import 'sheets.dart';
import 'store.dart';

const Color kTag = Color(0xFF252839);
const Color kOnTag = Color(0xFFFFFFFF);
const Color kTagTrack = Color(0x55FFBDB2);
const Color kOver = Color(0xFFFF525F);
const Color kWarn = Color(0xFFFFBDB2);

class TripScreen extends StatefulWidget {
  const TripScreen({super.key, required this.store, required this.tripId});
  final Store store;
  final String tripId;

  @override
  State<TripScreen> createState() => _TripScreenState();
}

class _TripScreenState extends State<TripScreen> {
  final PriceScanner _scanner = PriceScanner();
  final ImagePicker _picker = ImagePicker();
  bool _busy = false;
  final TextEditingController _itemSearchController = TextEditingController();
  String _itemQuery = '';
  String _categoryFilter = 'All';

  @override
  void dispose() {
    _scanner.dispose();
    _itemSearchController.dispose();
    super.dispose();
  }

  Future<String> _keepImage(String tempPath) async {
    final Directory docs = await getApplicationDocumentsDirectory();
    final Directory dir = Directory('${docs.path}/scans');
    if (!await dir.exists()) await dir.create(recursive: true);
    final String dest = '${dir.path}/${newId()}.jpg';
    await File(tempPath).copy(dest);
    return dest;
  }

  void _snack(String msg, {SnackBarAction? action}) {
    final ScaffoldMessengerState m = ScaffoldMessenger.of(context);
    m.removeCurrentSnackBar();
    m.clearSnackBars();
    m.showSnackBar(
      SnackBar(
        content: Text(msg),
        action: action,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _scan(Trip trip, {bool fromGallery = false}) async {
    if (_busy) return;
    // A previous 'Added item' message belongs to this route. Remove it before
    // opening the camera so it cannot float over the scanner screen.
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    messenger.removeCurrentSnackBar();
    messenger.clearSnackBars();
    setState(() => _busy = true);
    try {
      String? imagePath;
      if (fromGallery) {
        final XFile? image = await _picker.pickImage(
          source: ImageSource.gallery,
          maxWidth: 1600,
          imageQuality: 88,
        );
        imagePath = image?.path;
      } else {
        imagePath = await Navigator.of(context).push<String>(
          MaterialPageRoute<String>(
            builder: (_) => const BuiltInCameraScreen(),
          ),
        );
      }
      if (imagePath == null || !mounted) return;

      final String path = await _keepImage(imagePath);
      final ScanResult result = await _scanner.scan(path);
      if (!mounted) return;
      if (result.priceCents != null) {
        final Item item = Item(
          id: newId(),
          name: result.name ?? 'Item',
          priceCents: result.priceCents!,
          cat: result.category,
          imagePath: path,
        );
        widget.store.addItem(trip, item);
        final bool over = trip.leftCents < 0;
        _snack(
          'Added ${item.name} · ${peso(item.priceCents)}${over ? ' · over budget' : ''}',
          action: SnackBarAction(
            label: 'Undo',
            onPressed: () => widget.store.removeItem(trip, item.id),
          ),
        );
      } else {
        await _openItemSheet(
          trip,
          Item(id: newId(), name: result.name ?? '', priceCents: 0, cat: result.category, imagePath: path),
          isNew: true,
          note: 'Could not read the price. Type it in to add this item.',
        );
      }
    } catch (_) {
      if (mounted) _snack('Could not read that image. Try again with the price tag filling the frame.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openItemSheet(Trip trip, Item item, {required bool isNew, String? note}) async {
    final ItemSheetResult? r = await showItemSheet(context, item: item, isNew: isNew, note: note);
    if (r == null || !mounted) return;
    if (r.delete) {
      final int at = trip.items.indexOf(item);
      widget.store.removeItem(trip, item.id);
      _snack('Removed ${item.name}', action: SnackBarAction(label: 'Undo', onPressed: () => widget.store.insertItemAt(trip, at < 0 ? 0 : at, item)));
      return;
    }
    if (isNew) {
      item
        ..name = r.name
        ..priceCents = r.priceCents
        ..qty = r.qty
        ..cat = r.cat;
      widget.store.addItem(trip, item);
    } else {
      widget.store.editItem(item, name: r.name, priceCents: r.priceCents, qty: r.qty, cat: r.cat);
    }
    if (trip.leftCents < 0) _snack('Over budget by ${peso(-trip.leftCents)}');
  }

  Future<void> _editBudget(Trip trip) async {
    final TripSheetResult? r = await showTripSheet(context, name: trip.name, budgetCents: trip.budgetCents);
    if (r == null || !mounted) return;
    if (r.delete) {
      widget.store.deleteTrip(trip);
      Navigator.of(context).pop();
      return;
    }
    widget.store.updateTrip(trip, name: r.name, budgetCents: r.budgetCents);
  }

  Future<void> _finish(Trip trip) async {
    final bool over = trip.leftCents < 0;
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: const Text('Finish trip?'),
        content: Text(
          'Budget ${peso(trip.budgetCents)}\nSpent ${peso(trip.spentCents)}\n${over ? 'Over by' : 'Left over'} ${peso(trip.leftCents.abs())}',
        ),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Keep shopping')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Finish')),
        ],
      ),
    );
    if (ok == true) widget.store.updateTrip(trip, done: true);
  }

  Future<void> _copySummary(Trip trip) async {
    final List<String> lines = <String>[
      'subayBUY - ${trip.name}',
      showDate(trip.date),
      'Status: ${trip.done ? 'Completed' : 'Active'}',
      'Budget: ${peso(trip.budgetCents)}',
      'Spent: ${peso(trip.spentCents)}',
      'Remaining: ${peso(trip.leftCents)}',
      '',
      'ITEMS',
      ...trip.items.map((Item item) => '${item.name} | ${item.qty} x ${peso(item.priceCents)} = ${peso(item.lineCents)}'),
    ];
    await Clipboard.setData(ClipboardData(text: lines.join('\n')));
    if (mounted) _snack('Trip summary copied. You can paste it into a message or note.');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.store,
      builder: (BuildContext context, Widget? _) {
        final Trip? trip = widget.store.tripById(widget.tripId);
        if (trip == null) {
          return const Scaffold(body: Center(child: Text('Trip not found')));
        }
        final ThemeData theme = Theme.of(context);
        final List<String> categories = <String>{...trip.items.map((Item i) => i.cat)}.toList()..sort();
        categories.insert(0, 'All');
        final String selectedCategory = categories.contains(_categoryFilter) ? _categoryFilter : 'All';
        final String query = _itemQuery.trim().toLowerCase();
        final List<Item> visibleItems = trip.items.where((Item item) {
          final bool matchesText = query.isEmpty || item.name.toLowerCase().contains(query);
          final bool matchesCategory = selectedCategory == 'All' || item.cat == selectedCategory;
          return matchesText && matchesCategory;
        }).toList();
        return Scaffold(
          appBar: AppBar(
            title: Text(trip.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            actions: <Widget>[
              IconButton(
                tooltip: 'Copy trip summary',
                onPressed: () => _copySummary(trip),
                icon: const Icon(Icons.copy_all_outlined),
              ),
              if (!trip.done)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilledButton.tonal(onPressed: () => _finish(trip), child: const Text('Finish')),
                )
              else
                Padding(
                  padding: const EdgeInsets.only(right: 16),
                  child: Center(child: Text('FINISHED', style: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w800))),
                ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            children: <Widget>[
              Text(showDate(trip.date), style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
              const SizedBox(height: 10),
              _TagCard(trip: trip, onTap: () => _editBudget(trip)),
              const SizedBox(height: 22),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: <Widget>[
                  Text('SHOPPING CART (${trip.itemCount})', style: theme.textTheme.labelLarge?.copyWith(letterSpacing: 1.2, color: theme.colorScheme.onSurfaceVariant, fontWeight: FontWeight.w800)),
                  Text(peso(trip.spentCents), style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                ],
              ),
              const SizedBox(height: 8),
              if (trip.items.isEmpty)
                _EmptyCart(done: trip.done)
              else ...<Widget>[
                TextField(
                  controller: _itemSearchController,
                  onChanged: (String value) => setState(() => _itemQuery = value),
                  decoration: InputDecoration(
                    hintText: 'Find an item in this cart',
                    prefixIcon: const Icon(Icons.search_rounded),
                    suffixIcon: _itemQuery.isEmpty
                        ? null
                        : IconButton(
                            tooltip: 'Clear item search',
                            onPressed: () {
                              _itemSearchController.clear();
                              setState(() => _itemQuery = '');
                            },
                            icon: const Icon(Icons.close_rounded),
                          ),
                  ),
                ),
                const SizedBox(height: 9),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: categories.map((String category) => Padding(
                      padding: const EdgeInsets.only(right: 7),
                      child: ChoiceChip(
                        label: Text(category),
                        selected: selectedCategory == category,
                        onSelected: (_) => setState(() => _categoryFilter = category),
                      ),
                    )).toList(),
                  ),
                ),
                const SizedBox(height: 8),
                if (visibleItems.isEmpty)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF2F0),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Text('No items match this search or category.', textAlign: TextAlign.center),
                  )
                else
                  ...visibleItems.map((Item i) => _ItemRow(
                        item: i,
                        editable: !trip.done,
                        onTap: trip.done ? null : () => _openItemSheet(trip, i, isNew: false),
                        onMinus: () => widget.store.changeQty(trip, i, -1),
                        onPlus: () {
                          widget.store.changeQty(trip, i, 1);
                          if (trip.leftCents < 0) _snack('Over budget by ${peso(-trip.leftCents)}');
                        },
                      )),
              ],
              if (trip.done)
                Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: OutlinedButton(
                    onPressed: () => widget.store.updateTrip(trip, done: false),
                    child: const Text('Reopen trip'),
                  ),
                ),
              const SizedBox(height: 90),
            ],
          ),
          bottomNavigationBar: trip.done
              ? null
              : SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: SizedBox(
                            height: 56,
                            child: FilledButton.icon(
                              onPressed: _busy ? null : () => _scan(trip),
                              icon: _busy
                                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 3))
                                  : const Icon(Icons.photo_camera_outlined),
                              label: Text(_busy ? 'Reading price tag…' : 'Scan price tag', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        SizedBox(
                          width: 48,
                          height: 56,
                          child: IconButton.filledTonal(
                            tooltip: 'Choose photo from gallery',
                            onPressed: _busy ? null : () => _scan(trip, fromGallery: true),
                            icon: const Icon(Icons.photo_library_outlined),
                          ),
                        ),
                        const SizedBox(width: 6),
                        SizedBox(
                          width: 52,
                          height: 56,
                          child: IconButton.filledTonal(
                            tooltip: 'Add item by hand',
                            onPressed: _busy ? null : () => _openItemSheet(trip, Item(id: newId(), name: '', priceCents: 0), isNew: true),
                            icon: const Icon(Icons.add),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        );
      },
    );
  }
}

class _TagCard extends StatelessWidget {
  const _TagCard({required this.trip, required this.onTap});
  final Trip trip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final int left = trip.leftCents;
    final double used = trip.budgetCents > 0 ? trip.spentCents / trip.budgetCents : 1.0;
    final bool over = left < 0;
    final bool warn = !over && used >= 0.8;
    final Color accent = over ? kOver : (warn ? kWarn : kOnTag);
    return Material(
      color: kTag,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(over ? 'OVER BUDGET' : 'BUDGET LEFT', style: const TextStyle(color: kOnTag, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.4)),
                  const Row(
                    children: <Widget>[
                      Icon(Icons.edit_outlined, size: 14, color: kOnTag),
                      SizedBox(width: 4),
                      Text('EDIT', style: TextStyle(color: kOnTag, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 6),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(peso(left), style: TextStyle(color: over ? kOver : kOnTag, fontSize: 64, height: 1.05, fontWeight: FontWeight.w900)),
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(999),
                child: LinearProgressIndicator(
                  value: used.clamp(0.0, 1.0).toDouble(),
                  minHeight: 10,
                  backgroundColor: kTagTrack,
                  valueColor: AlwaysStoppedAnimation<Color>(accent),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Flexible(child: Text('Used ${(used * 100).round()}% of ${peso(trip.budgetCents)}', style: const TextStyle(color: kOnTag, fontWeight: FontWeight.w600))),
                  const SizedBox(width: 8),
                  Text('In cart ${peso(trip.spentCents)}', style: const TextStyle(color: kOnTag, fontWeight: FontWeight.w800)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ItemRow extends StatelessWidget {
  const _ItemRow({
    required this.item,
    required this.editable,
    required this.onTap,
    required this.onMinus,
    required this.onPlus,
  });
  final Item item;
  final bool editable;
  final VoidCallback? onTap;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme cs = theme.colorScheme;
    final String initial = item.name.trim().isEmpty ? '?' : item.name.trim()[0].toUpperCase();
    Widget thumb = Center(child: Text(initial, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: cs.onSurfaceVariant)));
    final String? img = item.imagePath;
    if (img != null) {
      thumb = Image.file(
        File(img),
        fit: BoxFit.cover,
        cacheWidth: 144,
        errorBuilder: (BuildContext c, Object e, StackTrace? s) => Center(child: Text(initial, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: cs.onSurfaceVariant))),
      );
    }
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      color: cs.surfaceContainer,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: cs.outlineVariant)),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Container(width: 52, height: 52, color: cs.surfaceContainerHighest, child: thumb),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(item.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, height: 1.2)),
                    const SizedBox(height: 4),
                    Text(
                      item.qty > 1 ? '${item.cat} · ${peso(item.priceCents)} each' : item.cat,
                      style: theme.textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(peso(item.lineCents), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  if (editable)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        _StepBtn(icon: Icons.remove, onTap: item.qty > 1 ? onMinus : null),
                        SizedBox(width: 26, child: Text('${item.qty}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800))),
                        _StepBtn(icon: Icons.add, onTap: onPlus),
                      ],
                    )
                  else
                    Text('× ${item.qty}', style: theme.textTheme.bodySmall),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StepBtn extends StatelessWidget {
  const _StepBtn({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkResponse(
      onTap: onTap,
      radius: 22,
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: Icon(icon, size: 18, color: onTap == null ? Theme.of(context).disabledColor : null),
      ),
    );
  }
}

class _EmptyCart extends StatelessWidget {
  const _EmptyCart({required this.done});
  final bool done;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.outlineVariant, width: 1.5),
      ),
      child: Column(
        children: <Widget>[
          Text('Your cart is empty', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(
            done ? 'Nothing was added on this trip.' : 'Tap Scan price tag and frame the shelf tag. Or add an item by hand with the + button.',
            textAlign: TextAlign.center,
            style: TextStyle(color: theme.colorScheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}
