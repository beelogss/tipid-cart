# subayBUY

A shopping budget tracker. Set a budget, scan shelf price tags with the camera, and track purchases offline.

## Brand assets

- Primary logo: `assets/subaybuy_logo.png`
- Android launcher icon source: `assets/subaybuy_app_icon.png`
- Brand colors: white `#FFFFFF`, coral `#FF525F`, navy `#252839`, peach `#FFBDB2`.

## Build

Run `flutter pub get`, then `dart run flutter_launcher_icons`, then `flutter build apk --debug` (or `--release` when release signing is configured).

The app keeps the existing local storage implementation and storage key. Keep the existing Android application ID and signing configuration when building an update over an already installed copy.
