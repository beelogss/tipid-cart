import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tipid_cart/models.dart';
import 'package:tipid_cart/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  test('duplicateTrip creates an independent active copy', () {
    final Store store = Store();
    final Trip original = store.addTrip('Weekly groceries', 200000);
    final Item originalItem = Item(
      id: 'original-item',
      name: 'Milk',
      priceCents: 12500,
      qty: 2,
      cat: 'Drinks',
    );
    store.addItem(original, originalItem);
    store.updateTrip(original, done: true);

    final Trip copy = store.duplicateTrip(original);

    expect(copy.id, isNot(original.id));
    expect(copy.name, 'Weekly groceries (copy)');
    expect(copy.done, isFalse);
    expect(copy.budgetCents, original.budgetCents);
    expect(copy.items, hasLength(1));
    expect(copy.items.single.id, isNot(original.items.single.id));
    expect(copy.items.single.name, original.items.single.name);
    expect(copy.items.single.priceCents, original.items.single.priceCents);
    expect(copy.items.single.qty, original.items.single.qty);
    expect(store.trips.first, same(copy));
  });
}
