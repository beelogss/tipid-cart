const List<String> kCats = <String>[
  'Grocery',
  'Snacks',
  'Drinks',
  'Household',
  'Personal care',
  'Other',
];

String newId() => DateTime.now().microsecondsSinceEpoch.toRadixString(36);

/// Money is kept in centavos (int) so the totals never drift.
String peso(int cents) {
  final bool neg = cents < 0;
  final int c = cents.abs();
  final String whole = (c ~/ 100).toString().replaceAllMapped(
        RegExp(r'\B(?=(\d{3})+(?!\d))'),
        (Match m) => ',',
      );
  final String frac = (c % 100).toString().padLeft(2, '0');
  return '${neg ? '-' : ''}₱$whole.$frac';
}

/// Turns what the user typed ("79.75", "1,950") into centavos, or null if invalid.
int? parseCents(String input) {
  final String t = input.replaceAll(',', '').trim();
  if (t.isEmpty) return null;
  final double? d = double.tryParse(t);
  if (d == null || d < 0 || d > 9999999) return null;
  return (d * 100).round();
}

class Item {
  Item({
    required this.id,
    required this.name,
    required this.priceCents,
    this.qty = 1,
    this.cat = 'Grocery',
    this.imagePath,
  });

  String id;
  String name;
  int priceCents;
  int qty;
  String cat;
  String? imagePath;

  int get lineCents => priceCents * qty;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'price': priceCents,
        'qty': qty,
        'cat': cat,
        'img': imagePath,
      };

  factory Item.fromJson(Map<String, dynamic> j) => Item(
        id: j['id'] as String,
        name: (j['name'] as String?) ?? 'Item',
        priceCents: (j['price'] as num).toInt(),
        qty: ((j['qty'] as num?) ?? 1).toInt(),
        cat: (j['cat'] as String?) ?? 'Other',
        imagePath: j['img'] as String?,
      );
}

class Trip {
  Trip({
    required this.id,
    required this.name,
    required this.date,
    required this.budgetCents,
    this.done = false,
    List<Item>? items,
  }) : items = items ?? <Item>[];

  String id;
  String name;
  DateTime date;
  int budgetCents;
  bool done;
  List<Item> items;

  int get spentCents => items.fold<int>(0, (int a, Item i) => a + i.lineCents);
  int get leftCents => budgetCents - spentCents;
  int get itemCount => items.fold<int>(0, (int a, Item i) => a + i.qty);

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'date': date.toIso8601String(),
        'budget': budgetCents,
        'done': done,
        'items': items.map((Item i) => i.toJson()).toList(),
      };

  factory Trip.fromJson(Map<String, dynamic> j) => Trip(
        id: j['id'] as String,
        name: (j['name'] as String?) ?? 'Shopping trip',
        date: DateTime.tryParse((j['date'] as String?) ?? '') ?? DateTime.now(),
        budgetCents: (j['budget'] as num).toInt(),
        done: (j['done'] as bool?) ?? false,
        items: ((j['items'] as List<dynamic>?) ?? <dynamic>[])
            .map((dynamic e) => Item.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

const List<String> _months = <String>[
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

String showDate(DateTime d) => '${_months[d.month - 1]} ${d.day}, ${d.year}';


/// A product the user plans to buy in a future shopping trip.
class WishlistEntry {
  WishlistEntry({
    required this.id,
    required this.name,
    required this.estimatedPriceCents,
    required this.category,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  final String id;
  String name;
  int estimatedPriceCents;
  String category;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'estimatedPrice': estimatedPriceCents,
        'category': category,
        'createdAt': createdAt.toIso8601String(),
      };

  factory WishlistEntry.fromJson(Map<String, dynamic> json) => WishlistEntry(
        id: json['id'] as String,
        name: (json['name'] as String?) ?? 'Item',
        estimatedPriceCents: ((json['estimatedPrice'] as num?) ?? 0).toInt(),
        category: (json['category'] as String?) ?? 'Other',
        createdAt: DateTime.tryParse((json['createdAt'] as String?) ?? ''),
      );
}

/// A unit-price observation recorded when an item is added or its price changes.
class PriceRecord {
  const PriceRecord({
    required this.id,
    required this.name,
    required this.priceCents,
    required this.category,
    required this.recordedAt,
  });

  final String id;
  final String name;
  final int priceCents;
  final String category;
  final DateTime recordedAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'price': priceCents,
        'category': category,
        'recordedAt': recordedAt.toIso8601String(),
      };

  factory PriceRecord.fromJson(Map<String, dynamic> json) => PriceRecord(
        id: json['id'] as String,
        name: (json['name'] as String?) ?? 'Item',
        priceCents: ((json['price'] as num?) ?? 0).toInt(),
        category: (json['category'] as String?) ?? 'Other',
        recordedAt: DateTime.tryParse((json['recordedAt'] as String?) ?? '') ?? DateTime.now(),
      );
}
