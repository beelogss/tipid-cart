import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tipid_cart/notifications.dart';

void main() {
  testWidgets('notice with inline undo auto-dismisses in accessible navigation mode',
      (WidgetTester tester) async {
    final GlobalKey<ScaffoldMessengerState> messengerKey =
        GlobalKey<ScaffoldMessengerState>();
    int undoCount = 0;

    await tester.pumpWidget(
      MaterialApp(
        builder: (BuildContext context, Widget? child) => MediaQuery(
          data: MediaQuery.of(context).copyWith(accessibleNavigation: true),
          child: child!,
        ),
        home: ScaffoldMessenger(
          key: messengerKey,
          child: Scaffold(
            body: Builder(
              builder: (BuildContext context) => Center(
                child: ElevatedButton(
                  onPressed: () => showTransientNotice(
                    messengerKey.currentState!,
                    'Added Milk · ₱25.00',
                    onUndo: () => undoCount++,
                  ),
                  child: const Text('Show notice'),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('Show notice'));
    await tester.pump();
    expect(find.text('Added Milk · ₱25.00'), findsOneWidget);
    expect(find.text('Undo'), findsOneWidget);

    await tester.pump(const Duration(seconds: 3));
    await tester.pumpAndSettle();
    expect(find.text('Added Milk · ₱25.00'), findsNothing);
    expect(undoCount, 0);
  });

  testWidgets('inline Undo still works before the notice times out',
      (WidgetTester tester) async {
    final GlobalKey<ScaffoldMessengerState> messengerKey =
        GlobalKey<ScaffoldMessengerState>();
    int undoCount = 0;

    await tester.pumpWidget(MaterialApp(
      home: ScaffoldMessenger(
        key: messengerKey,
        child: Scaffold(
          body: Builder(
            builder: (BuildContext context) => TextButton(
              onPressed: () => showTransientNotice(
                messengerKey.currentState!,
                'Added Bread · ₱30.00',
                onUndo: () => undoCount++,
              ),
              child: const Text('Show notice'),
            ),
          ),
        ),
      ),
    ));

    await tester.tap(find.text('Show notice'));
    await tester.pump();
    await tester.tap(find.text('Undo'));
    await tester.pumpAndSettle();
    expect(undoCount, 1);
    expect(find.text('Added Bread · ₱30.00'), findsNothing);
  });
}
