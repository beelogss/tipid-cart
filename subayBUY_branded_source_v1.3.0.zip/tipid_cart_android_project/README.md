# subayBUY v1.3.0

An offline-first Android shopping budget tracker. Create shopping trips, set budgets, scan shelf price tags with on-device OCR, add or edit items manually, and review trip spending. Data is stored locally on the device; no account is required.

## Dashboard and brand

- Compact subayBUY logo header with the coral/navy/peach/white palette
- Custom Android launcher icon generated from `assets/subaybuy_app_icon.png`
- Quick access to Wishlist and Spending Insights

## Shopping tools

- Shopping trips with individual budgets and active/completed status
- Remaining-budget progress and an 80% budget warning
- Monthly spending overview
- Camera scanning and photo-gallery scanning for shelf price tags
- Editable OCR results, manual item entry, quantities, and product categories
- Search and status filters for trips; search and category filters for cart items
- Copyable trip summaries

## New in v1.3.0

- Wishlist planner: save products, optional estimated prices and categories; edit, remove, or add a saved product to an active trip
- Spending Insights: total spending, average spend per trip, six-month totals by trip month, and category breakdown
- Price History: records item prices when products are added or their name/unit price is changed; compares the latest observation with the previous observation

## Brand colors

- White: `#FFFFFF`
- Coral: `#FF525F`
- Navy: `#252839`
- Peach: `#FFBDB2`

## Local data and compatibility

- Existing shopping trips continue to use the original `tipid_cart_v1` SharedPreferences key.
- Wishlist and price-history data use separate keys and do not overwrite the existing trip data.
- Existing saved trip items are used to seed an initial price history when no price history exists yet.
- Keep the existing Flutter package name and Android application ID unchanged when making future updates.

## Build

Use the repository workflow `/.github/workflows/subayBUY-build-v1.3.0.yml`. It extracts `subayBUY_branded_source_v1.3.0.zip`, generates the Android project, generates the custom launcher icons, runs tests and analysis, and builds an arm64 debug APK named `subayBUY.apk`.
