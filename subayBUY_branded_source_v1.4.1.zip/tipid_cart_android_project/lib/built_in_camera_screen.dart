import 'dart:async';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

const Color _cameraCoral = Color(0xFFFF525F);

class BuiltInCameraScreen extends StatefulWidget {
  const BuiltInCameraScreen({super.key});

  @override
  State<BuiltInCameraScreen> createState() => _BuiltInCameraScreenState();
}

class _BuiltInCameraScreenState extends State<BuiltInCameraScreen>
    with WidgetsBindingObserver {
  CameraController? _controller;
  bool _loading = true;
  bool _opening = false;
  bool _capturing = false;
  bool _torchOn = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_openCamera());
  }

  Future<void> _openCamera() async {
    if (_opening || !mounted) return;
    _opening = true;
    if (mounted && !_loading) {
      setState(() { _loading = true; _error = null; });
    } else {
      _error = null;
    }
    CameraController? nextController;
    try {
      final List<CameraDescription> cameras = await availableCameras();
      if (cameras.isEmpty) throw CameraException('NoCamera', 'No camera was found on this device.');
      final CameraDescription selected = cameras.firstWhere(
        (CameraDescription camera) => camera.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );
      nextController = CameraController(
        selected,
        ResolutionPreset.high,
        enableAudio: false,
      );
      await nextController.initialize();
      await nextController.setFlashMode(FlashMode.off);
      if (!mounted) {
        await nextController.dispose();
        return;
      }
      _controller = nextController;
      setState(() { _loading = false; _torchOn = false; });
    } on CameraException catch (error) {
      if (nextController != null) await nextController.dispose();
      if (mounted) {
        setState(() {
          _loading = false;
          _error = error.description ?? error.code;
        });
      }
    } catch (error) {
      if (nextController != null) await nextController.dispose();
      if (mounted) setState(() { _loading = false; _error = error.toString(); });
    } finally {
      _opening = false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) {
      final CameraController? old = _controller;
      _controller = null;
      if (old != null) unawaited(old.dispose());
    } else if (state == AppLifecycleState.resumed && _controller == null) {
      unawaited(_openCamera());
    }
  }

  Future<void> _toggleTorch() async {
    final CameraController? controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    final bool next = !_torchOn;
    try {
      await controller.setFlashMode(next ? FlashMode.torch : FlashMode.off);
      if (mounted) setState(() => _torchOn = next);
    } on CameraException {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Flash is not available on this camera.')),
        );
      }
    }
  }

  Future<void> _capture() async {
    final CameraController? controller = _controller;
    if (controller == null || !controller.value.isInitialized || _capturing) return;
    setState(() => _capturing = true);
    try {
      final XFile image = await controller.takePicture();
      if (!mounted) return;
      Navigator.of(context).pop<String>(image.path);
    } on CameraException catch (error) {
      if (mounted) {
        setState(() => _capturing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.description ?? 'Unable to capture photo.')),
        );
      }
    } catch (_) {
      if (mounted) {
        setState(() => _capturing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Unable to capture photo. Please try again.')),
        );
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    final CameraController? old = _controller;
    _controller = null;
    if (old != null) unawaited(old.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final CameraController? controller = _controller;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('Scan price tag'),
        actions: <Widget>[
          IconButton(
            tooltip: _torchOn ? 'Turn flash off' : 'Turn flash on',
            onPressed: controller == null ? null : _toggleTorch,
            icon: Icon(_torchOn ? Icons.flash_on_rounded : Icons.flash_off_rounded),
          ),
        ],
      ),
      body: _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    const Icon(Icons.no_photography_outlined, color: Colors.white70, size: 48),
                    const SizedBox(height: 14),
                    const Text('Camera unavailable', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                    const SizedBox(height: 18),
                    FilledButton(onPressed: () => unawaited(_openCamera()), child: const Text('Try again')),
                  ],
                ),
              ),
            )
          : _loading || controller == null || !controller.value.isInitialized
              ? const Center(child: CircularProgressIndicator(color: _cameraCoral))
              : Column(
                  children: <Widget>[
                    Expanded(
                      child: Stack(
                        fit: StackFit.expand,
                        children: <Widget>[
                          Center(
                            child: AspectRatio(
                              aspectRatio: controller.value.aspectRatio,
                              child: CameraPreview(controller),
                            ),
                          ),
                          IgnorePointer(
                            child: Center(
                              child: Container(
                                width: MediaQuery.sizeOf(context).width * 0.84,
                                height: 150,
                                decoration: BoxDecoration(
                                  border: Border.all(color: _cameraCoral, width: 2.5),
                                  borderRadius: BorderRadius.circular(18),
                                ),
                              ),
                            ),
                          ),
                          const Positioned(
                            left: 20,
                            right: 20,
                            bottom: 22,
                            child: Text(
                              'I-frame ang buong price tag sa loob ng guide.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, shadows: <Shadow>[Shadow(blurRadius: 8, color: Colors.black)]),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SafeArea(
                      top: false,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 14, 20, 18),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: OutlinedButton(
                                onPressed: _capturing ? null : () => Navigator.of(context).pop<String>(),
                                style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54), minimumSize: const Size.fromHeight(52)),
                                child: const Text('Cancel'),
                              ),
                            ),
                            const SizedBox(width: 18),
                            SizedBox(
                              width: 68,
                              height: 68,
                              child: FloatingActionButton(
                                heroTag: 'capture-price-tag',
                                onPressed: _capturing ? null : _capture,
                                backgroundColor: _cameraCoral,
                                foregroundColor: Colors.white,
                                child: _capturing
                                    ? const CircularProgressIndicator(color: Colors.white)
                                    : const Icon(Icons.camera_alt_rounded, size: 30),
                              ),
                            ),
                            const SizedBox(width: 18),
                            const Expanded(
                              child: Text('Take photo', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }
}
