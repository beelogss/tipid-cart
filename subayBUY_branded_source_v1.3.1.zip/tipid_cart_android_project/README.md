# subayBUY v1.3.1

Offline shopping budget tracker built with Flutter.

## Features
- Shopping trips, budgets, product quantities and trip history
- Camera and gallery price-tag text recognition
- Trip search and status filters
- Wishlist planner
- Spending insights and category breakdown
- Local price history
- Local-only storage; no login or cloud account required

## Branding
- App display name: subayBUY
- Palette: #FFFFFF, #FF525F, #252839, #FFBDB2
- Dashboard logo: assets/subaybuy_logo.png
- Android launcher icon source: assets/subaybuy_app_icon.png

## Android build
The GitHub Actions workflow `.github/workflows/subayBUY-build-v1.3.1.yml`
extracts this project, generates the Android wrapper, installs dependencies,
generates launcher icons, runs tests and analysis, and builds an arm64 debug APK.

The current active additional screens are implemented in `lib/extra_screens.dart`.
The obsolete `lib/wishlist_screen.dart` duplicate has been removed because it
referenced an earlier, incompatible wishlist API and was not imported by `main.dart`.

## Data compatibility
The existing trip storage key `tipid_cart_v1` is preserved. Wishlist and price
history use separate local storage keys and do not overwrite the trip data.
