import 'package:flutter_test/flutter_test.dart';
import 'package:tipid_cart/budget_helper.dart';
import 'package:tipid_cart/models.dart';

void main() {
  group('Budget recovery suggestions', () {
    test('suggests reducing multi-quantity items from highest savings first', () {
      final Trip trip = Trip(
        id: 'trip-1',
        name: 'Groceries',
        date: DateTime(2026, 11, 1),
        budgetCents: 10000,
        items: <Item>[
          Item(id: 'a', name: 'Milk', priceCents: 7500, qty: 2),
          Item(id: 'b', name: 'Bread', priceCents: 3500, qty: 1),
          Item(id: 'c', name: 'Rice', priceCents: 12000, qty: 3),
        ],
      );

      final List<BudgetSavingSuggestion> suggestions =
          budgetSavingSuggestions(trip);

      expect(suggestions, hasLength(2));
      expect(suggestions.first.item.name, 'Rice');
      expect(suggestions.first.savingsCents, 12000);
      expect(suggestions.last.item.name, 'Milk');
      expect(suggestions.last.savingsCents, 7500);
    });

    test('does not suggest changing single-quantity or zero-price items', () {
      final Trip trip = Trip(
        id: 'trip-2',
        name: 'Small shop',
        date: DateTime(2026, 11, 1),
        budgetCents: 10000,
        items: <Item>[
          Item(id: 'a', name: 'Bread', priceCents: 3500, qty: 1),
          Item(id: 'b', name: 'Unpriced item', priceCents: 0, qty: 4),
        ],
      );

      expect(budgetSavingSuggestions(trip), isEmpty);
    });
  });
}
