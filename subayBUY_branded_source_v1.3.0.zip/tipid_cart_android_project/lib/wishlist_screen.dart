import 'package:flutter/material.dart';

import 'models.dart';
import 'sheets.dart';
import 'store.dart';

const Color _coral = Color(0xFFFF525F);
const Color _navy = Color(0xFF252839);
const Color _softPeach = Color(0xFFFFF2F0);

class WishlistScreen extends StatefulWidget {
  const WishlistScreen({super.key, required this.store});
  final Store store;

  @override
  State<WishlistScreen> createState() => _WishlistScreenState();
}

class _WishlistScreenState extends State<WishlistScreen> {
  final TextEditingController _search = TextEditingController();
  String _category = 'All';
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _editWish({WishItem? existing}) async {
    final WishItem? result = await showModalBottomSheet<WishItem>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (BuildContext context) => _WishItemSheet(existing: existing),
    );
    if (result == null || !mounted) return;
    if (existing == null) {
      widget.store.addWishItem(result);
    } else {
      widget.store.updateWishItem(
        existing,
        name: result.name,
        estimatedPriceCents: result.estimatedPriceCents,
        qty: result.qty,
        cat: result.cat,
        note: result.note,
      );
    }
  }

  Future<void> _moveToTrip(WishItem item) async {
    final List<Trip> activeTrips = widget.store.trips.where((Trip trip) => !trip.done).toList();
    if (activeTrips.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Create a shopping trip first, then you can move wishlist items into it.')),
      );
      return;
    }
    final Trip? selected = await showDialog<Trip>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Add to which trip?'),
        content: SizedBox(
          width: double.maxFinite,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 340),
            child: ListView(
              shrinkWrap: true,
              children: activeTrips.map((Trip trip) => ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.shopping_cart_outlined, color: _coral),
                title: Text(trip.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('${peso(trip.leftCents)} left'),
                onTap: () => Navigator.of(context).pop(trip),
              )).toList(),
            ),
          ),
        ),
        actions: <Widget>[TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel'))],
      ),
    );
    if (selected == null || !mounted) return;
    widget.store.addItem(selected, Item(
      id: newId(),
      name: item.name,
      priceCents: item.estimatedPriceCents,
      qty: item.qty,
      cat: item.cat,
    ));
    widget.store.deleteWishItem(item.id);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${item.name} added to ${selected.name} using your estimated price.')),
    );
  }

  Future<void> _deleteWish(WishItem item) async {
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Remove from wishlist?'),
        content: Text('Remove ${item.name} from your saved wishlist?'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Remove')),
        ],
      ),
    );
    if (ok == true) widget.store.deleteWishItem(item.id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Wishlist')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editWish(),
        backgroundColor: _coral,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Add item'),
      ),
      body: ListenableBuilder(
        listenable: widget.store,
        builder: (BuildContext context, Widget? child) {
          final List<WishItem> all = widget.store.wishlist;
          final int estimatedTotal = all.fold<int>(0, (int sum, WishItem item) => sum + item.estimatedTotalCents);
          final List<String> categories = <String>{...all.map((WishItem item) => item.cat)}.toList()..sort();
          if (!categories.contains(_category)) _category = 'All';
          final String q = _query.trim().toLowerCase();
          final List<WishItem> visible = all.where((WishItem item) {
            final bool matchText = q.isEmpty || item.name.toLowerCase().contains(q) || item.note.toLowerCase().contains(q);
            final bool matchCategory = _category == 'All' || item.cat == _category;
            return matchText && matchCategory;
          }).toList();
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: _softPeach, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFFFD5D0))),
                child: Row(children: <Widget>[
                  const Icon(Icons.favorite_rounded, color: _coral, size: 30),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                    const Text('SAVED FOR LATER', style: TextStyle(color: _navy, fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: 1.1)),
                    const SizedBox(height: 3),
                    Text(peso(estimatedTotal), style: const TextStyle(color: _navy, fontSize: 22, fontWeight: FontWeight.w900)),
                  ])),
                  Text('${all.length} item${all.length == 1 ? '' : 's'}', style: const TextStyle(color: _navy, fontWeight: FontWeight.w700)),
                ]),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _search,
                onChanged: (String value) => setState(() => _query = value),
                decoration: InputDecoration(
                  hintText: 'Search wishlist',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: _query.isEmpty ? null : IconButton(onPressed: () { _search.clear(); setState(() => _query = ''); }, icon: const Icon(Icons.close)),
                ),
              ),
              if (categories.isNotEmpty) ...<Widget>[
                const SizedBox(height: 10),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(children: <String>['All', ...categories].map((String cat) => Padding(
                    padding: const EdgeInsets.only(right: 7),
                    child: ChoiceChip(label: Text(cat), selected: _category == cat, onSelected: (_) => setState(() => _category = cat)),
                  )).toList()),
                ),
              ],
              const SizedBox(height: 12),
              if (all.isEmpty)
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(color: _softPeach, borderRadius: BorderRadius.circular(18)),
                  child: const Column(children: <Widget>[
                    Icon(Icons.bookmark_add_outlined, color: _coral, size: 42),
                    SizedBox(height: 10),
                    Text('Save items you plan to buy', style: TextStyle(color: _navy, fontWeight: FontWeight.w900, fontSize: 17)),
                    SizedBox(height: 5),
                    Text('Keep a list of products and estimated prices, then move them into a shopping trip when you are ready.', textAlign: TextAlign.center, style: TextStyle(color: _navy)),
                  ]),
                )
              else if (visible.isEmpty)
                const Padding(padding: EdgeInsets.all(24), child: Text('No wishlist items match your search.', textAlign: TextAlign.center))
              else
                ...visible.map((WishItem item) => Card(
                  margin: const EdgeInsets.only(bottom: 9),
                  color: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: Color(0xFFFFD5D0))),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(13, 12, 8, 10),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                      Row(children: <Widget>[
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                          Text(item.name, style: const TextStyle(color: _navy, fontWeight: FontWeight.w800, fontSize: 15)),
                          const SizedBox(height: 3),
                          Text('${item.cat} · ${item.qty} × ${peso(item.estimatedPriceCents)}', style: const TextStyle(color: Color(0xFF777989), fontSize: 12)),
                        ])),
                        Text(peso(item.estimatedTotalCents), style: const TextStyle(color: _navy, fontWeight: FontWeight.w900, fontSize: 16)),
                      ]),
                      if (item.note.trim().isNotEmpty) ...<Widget>[
                        const SizedBox(height: 5),
                        Text(item.note, style: const TextStyle(color: Color(0xFF777989), fontSize: 12)),
                      ],
                      const SizedBox(height: 8),
                      Row(children: <Widget>[
                        TextButton.icon(onPressed: () => _editWish(existing: item), icon: const Icon(Icons.edit_outlined, size: 17), label: const Text('Edit')),
                        TextButton.icon(onPressed: () => _moveToTrip(item), icon: const Icon(Icons.add_shopping_cart, size: 17), label: const Text('Add to trip')),
                        const Spacer(),
                        IconButton(tooltip: 'Remove', onPressed: () => _deleteWish(item), icon: const Icon(Icons.delete_outline, color: Color(0xFFB3261E))),
                      ]),
                    ]),
                  ),
                )),
            ],
          );
        },
      ),
    );
  }
}

class _WishItemSheet extends StatefulWidget {
  const _WishItemSheet({this.existing});
  final WishItem? existing;

  @override
  State<_WishItemSheet> createState() => _WishItemSheetState();
}

class _WishItemSheetState extends State<_WishItemSheet> {
  late final TextEditingController _name;
  late final TextEditingController _price;
  late final TextEditingController _note;
  late int _qty;
  late String _cat;
  String? _error;

  @override
  void initState() {
    super.initState();
    final WishItem? item = widget.existing;
    _name = TextEditingController(text: item?.name ?? '');
    _price = TextEditingController(text: item == null || item.estimatedPriceCents == 0 ? '' : (item.estimatedPriceCents / 100).toStringAsFixed(2));
    _note = TextEditingController(text: item?.note ?? '');
    _qty = item?.qty ?? 1;
    _cat = item?.cat ?? 'Grocery';
  }

  @override
  void dispose() {
    _name.dispose();
    _price.dispose();
    _note.dispose();
    super.dispose();
  }

  void _save() {
    final String name = _name.text.trim();
    final int? price = parseCents(_price.text);
    if (name.isEmpty) { setState(() => _error = 'Enter an item name.'); return; }
    if (price == null || price <= 0) { setState(() => _error = 'Enter an estimated price greater than zero.'); return; }
    Navigator.of(context).pop(WishItem(
      id: widget.existing?.id ?? newId(),
      name: name,
      estimatedPriceCents: price,
      qty: _qty,
      cat: _cat,
      note: _note.text.trim(),
      addedAt: widget.existing?.addedAt,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final double bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + bottom),
      child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        Text(widget.existing == null ? 'Add to wishlist' : 'Edit wishlist item', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 14),
        TextField(controller: _name, textCapitalization: TextCapitalization.sentences, maxLength: 60, decoration: const InputDecoration(labelText: 'Item name', counterText: '')),
        const SizedBox(height: 10),
        TextField(controller: _price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Estimated price (each)', prefixText: '₱ ')),
        const SizedBox(height: 12),
        Row(children: <Widget>[
          const Text('Quantity', style: TextStyle(fontWeight: FontWeight.w700)),
          const Spacer(),
          IconButton(onPressed: _qty > 1 ? () => setState(() => _qty--) : null, icon: const Icon(Icons.remove_circle_outline)),
          Text('$_qty', style: const TextStyle(fontWeight: FontWeight.w800)),
          IconButton(onPressed: _qty < 99 ? () => setState(() => _qty++) : null, icon: const Icon(Icons.add_circle_outline)),
        ]),
        Wrap(spacing: 7, runSpacing: 4, children: kCats.map((String cat) => ChoiceChip(label: Text(cat), selected: _cat == cat, onSelected: (_) => setState(() => _cat = cat))).toList()),
        const SizedBox(height: 10),
        TextField(controller: _note, maxLength: 120, decoration: const InputDecoration(labelText: 'Note (optional)', counterText: '')),
        if (_error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, height: 50, child: FilledButton(onPressed: _save, child: Text(widget.existing == null ? 'Save to wishlist' : 'Save changes'))),
      ])),
    );
  }
}
