# subayBUY v1.5.0

Offline shopping budget tracker built with Flutter.

## Core features
- Shopping trips, budgets, quantities, trip history, and reusable trip copies
- Built-in camera and gallery price-tag text recognition
- Manual item entry, cart search, and category filters
- Wishlist planner with add-to-trip actions
- Spending insights, price history, and unit-price comparison
- On-device recent-product quick add based on saved price history
- Optional budget-recovery suggestions for multi-quantity cart items
- Animated budget progress, threshold notices, haptic feedback, and Undo actions
- Local-only storage; no login or cloud account required

## Branding
- App display name: subayBUY
- Palette: #FFFFFF, #FF525F, #252839, #FFBDB2
- Dashboard logo: assets/subaybuy_logo.png
- Android launcher icon source: assets/subaybuy_app_icon.png

## Android build
The GitHub Actions workflow `.github/workflows/subayBUY-build-v1.5.0.yml`
extracts this project, generates the Android wrapper, installs dependencies,
generates launcher icons, runs tests and analysis, and builds an arm64 debug APK.

## Data compatibility
Existing local storage keys are preserved:
- `tipid_cart_v1` for shopping trips
- `subaybuy_wishlist_v1` for the wishlist
- `subaybuy_price_history_v1` for local price history

No migration or account sign-in is required for this update.
